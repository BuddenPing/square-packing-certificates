from pathlib import Path
from fractions import Fraction as Q
import sys,json,hashlib
ROOT=Path.cwd();HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'outputs/formal302_20261012'))
from exact_sat import basis,dot,exact_check
from exact_polygon import audit
for n in [146,261]:
    parent=HERE/f'inherited{n}';source=parent/'closure100/source.cert'
    lines=[s.split()for s in source.read_text().splitlines()if s.strip()and not s.startswith('#')]
    raw={'n':int(lines[0][0]),'s_exact':lines[0][1],'squares':lines[1:]}
    assert n==raw['n']==len(raw['squares'])
    (parent/'raw.cert.json').write_text(json.dumps(raw,indent=2)+'\n')
    rawcheck=exact_check(raw)
    L=Q(raw['s_exact']);squares=[tuple(map(Q,s))for s in raw['squares']];axes=[basis(s[2])for s in squares]
    q=Q(1);limiting=['none']
    for i,(x,y,t)in enumerate(squares):
        h=sum(map(abs,axes[i][0]))/2
        for k,d in enumerate([x,y,L-x,L-y]):
            assert d>0
            if h/d>q:q=h/d;limiting=['wall',i,k]
        for j in range(i):
            delta=(x-squares[j][0],y-squares[j][1]);options=[]
            for k,normal in enumerate((*axes[i],*axes[j])):
                separation=abs(dot(delta,normal))
                support=sum(abs(dot(a,normal))for a in(*axes[i],*axes[j]))/2
                if separation:options.append((support/separation,k))
            requirement,k=min(options)
            if requirement>q:q=requirement;limiting=['pair',j,i,k]
    cert={'n':n,'s_exact':str(q*L),'squares':[[str(q*x),str(q*y),str(t)]for x,y,t in squares],
          'provenance':{'raw_certificate':str(parent/'raw.cert.json'),'raw_sha256':hashlib.sha256((parent/'raw.cert.json').read_bytes()).hexdigest(),'common_center_and_host_dilation':str(q),'physical_return_system':str(parent/'INHERITED-SYSTEM.json')}}
    check=exact_check(cert);poly=audit(cert)[0];assert check['valid']and poly['valid']
    best=Q(json.loads((HERE/f'affine7/n{n}-affine.cert.json').read_text())['s_exact'])
    assert q*L<best
    path=parent/f'n{n}.cert.json';path.write_text(json.dumps(cert,indent=2)+'\n')
    report={'n':n,'raw_check':rawcheck,'raw_side':str(L),'repair_q':str(q),'limiting':limiting,'certificate':str(path),'certificate_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'side_exact':str(q*L),'gain_from_affine_exact':str(best-q*L),'gain_from_affine_float':float(best-q*L),'sat':check,'polygon':poly}
    (parent/'VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
    print(n,'raw',rawcheck['valid'],'repair excess',float(q-1),'gain from affine',float(best-q*L),flush=True)
