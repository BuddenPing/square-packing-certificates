"""Recover the complete inherited return system of the two method controls.

The exact affine-centre refinements retain the original frames. As a
separate, predeclared question, realize their complete marked physical
contact systems at high precision: for each saved corner/side incidence,
p_j-p_i=n_i/2-R_j*corner/2+tau*J*n_i; all closed owner cycles sum to zero,
and the saved wall incidences close the container. Every variable frame
is tied to that coupled return system and stationarity, never independently
tuned. Preserve free owners and frozen parameters. No random perturbation,
angle sweep, optional flat-motion probe or forced KKT broadening is allowed.
An undeclared contact change terminates this proposal instead of silently
changing the physical word. Keep the exact complete decoder and compare
against the already verified full-affine witnesses before claiming a gain.
"""
from pathlib import Path
from fractions import Fraction as Q
import sys,json,importlib.util,hashlib
import mpmath as mp
ROOT=Path.cwd();HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('inherited',ROOT/'outputs/numerical_frontier_20261013/squish/run_inherited.py')
M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M);E=M.E
n=int(sys.argv[1]);out=HERE/f'inherited{n}';out.mkdir(exist_ok=True)
source=HERE/f'affine7/n{n}-affine.cert.json';cert=json.loads(source.read_text())
(out/'PROPOSAL.txt').write_text(__doc__+'\n')
mp.mp.dps=160
def value(q):
    q=Q(q);return mp.mpf(q.numerator)/q.denominator
with(out/'source.txt').open('w')as f:
    f.write(f'{n} {mp.nstr(value(cert["s_exact"]),150)}\n')
    for x,y,t in cert['squares']:
        f.write(' '.join(mp.nstr(z,150)for z in[value(x),value(y),2*mp.atan(value(t))*180/mp.pi])+'\n')
pack=E.Pack.load(out/'source.txt');cts,vv=E.find_contacts(pack,tol=1e-7);J,g=E.jacobian(pack,cts);lam,supp,eta=E.max_support(J)
(out/'INHERITED-SYSTEM.json').write_text(json.dumps({'n':n,'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'proposal':__doc__,'contact_equations':cts,'pure_corner_pairs':vv,'contact_descriptions':[E.describe(c)for c in cts],'equilibrium_residual':eta,'load_bearing_contacts':sum(bool(v)for v in supp),'load_bearing_equations':[c for c,v in zip(cts,supp)if v]},indent=2)+'\n')
print(n,'declared',len(cts),'contacts','equilibrium',eta,flush=True)
M.current=out/'closure100';M.current.mkdir(exist_ok=True);M.count=0
E.run(str(out/'source.txt'),dps=100,eps='1e-80',outdir=str(M.current),tol=1e-7)
