"""Realize predeclared inherited marked contact systems; no independent tuning."""
from pathlib import Path
import sys,json,hashlib
import mpmath as mp
O=Path(__file__).resolve().parent; R=O.parents[2]
sys.path.insert(0,str(R/'outputs/thirteen_sota_resolution_20261012/squish/n272-submission-evidence/solver'))
import exactsolve as E

_second=E.second_order
def second(*a,**kw):
    result=_second(*a,**kw)
    result.pop('_zero_modes',None)
    result['optional_flat_motion_probes']='omitted; only inherited contact realization authorized'
    return result
E.second_order=second

def preserve_free(P,free,log_=print,**kw):
    result=E.free_clearance(P,free)
    log_(f'  inherited free square placements retained: {free}')
    return result
E.place_free=preserve_free
_setup=E.KKT.setup; _newton=E.KKT.newton
current=None; count=0
def setup(self,*a,**kw):
    global count
    count+=1; self.capture_number=count
    p=current/f'attempt-{count:02d}';p.mkdir(parents=True,exist_ok=True)
    inv=json.loads((current.parent/'INHERITED-SYSTEM.json').read_text())
    declared={tuple(ct) for ct in inv['contact_equations']}
    extra=[ct for ct in self.A if tuple(ct) not in declared]
    # A changed incidence requires an explicit new proposal before realization.
    if extra: raise RuntimeError(f'Undeclared contact additions: {extra}')
    self.P.save(str(p/'before-projection.txt'),mp.mp.dps-5)
    (p/'EQUATIONS-BEFORE-SOLVE.json').write_text(json.dumps({'n':self.P.n,'equations':self.A,'variables':list(map(int,self.V)),'source_inventory_sha256':hashlib.sha256((current.parent/'INHERITED-SYSTEM.json').read_bytes()).hexdigest()},indent=2)+'\n')
    return _setup(self,*a,**kw)
def newton(self,*a,**kw):
    p=current/f'attempt-{self.capture_number:02d}'
    self.P.save(str(p/'pre-kkt-projection.txt'),mp.mp.dps-5)
    (p/'pre-kkt-state.json').write_text(json.dumps({'n':self.P.n,'S':mp.nstr(self.P.S,mp.mp.dps-5),'equations':self.A,'independent_equations':list(map(int,self.B)),'frozen_vars':list(map(int,self.frozen)),'frozen_values':{str(v):mp.nstr(self.P.get(v),mp.mp.dps-5) for v in self.frozen}},indent=2)+'\n')
    result=_newton(self,*a,**kw)
    self.P.save(str(p/'post-kkt.txt'),mp.mp.dps-5)
    return result
E.KKT.setup=setup; E.KKT.newton=newton

if __name__=='__main__':
    n=int(sys.argv[1]);dps=int(sys.argv[2]) if len(sys.argv)>2 else 100
    current=O/f'n{n}'/f'closure-{dps}';current.mkdir(exist_ok=True); count=0
    E.run(str(current.parent/'source.txt'),dps=dps,eps=f'1e-{dps-20}',outdir=str(current),tol=1e-10)
