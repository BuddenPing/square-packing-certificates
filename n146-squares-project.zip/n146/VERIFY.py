#!/usr/bin/env python3
"""Standalone exact package verification; Python3.10+, standard library only."""
from pathlib import Path
from fractions import Fraction as Q
import json,hashlib,gzip,sys,copy
if not __debug__:raise RuntimeError('Run without -O: assertions are verification checks.')
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'native'))
from convert_witness import check_identity,load
from exact_sat import exact_check,basis,dot,vertices
from exact_polygon import audit

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify_geometry(z):
 assert z['n']==len(z['squares']) and Q(z['s_exact'])>0
 sat=exact_check(z);pol=audit(z)[0];assert sat['valid']and pol['valid'];return {'sat':sat,'polygon':pol}
def negative(z,kind):
 z=copy.deepcopy(z)
 if kind=='duplicate':z['squares'][1]=z['squares'][0][:]
 else:z['squares'][0][0]='-2'
 s=exact_check(z)
 try:p=audit(z)[0]
 except AssertionError:p={'valid':False}
 assert not s['valid']and not p['valid'];return True

def verify_support_word(source,new):
 # Overridden below in the N261 package with the complete exact decoder.
 raise RuntimeError('Missing N261 support decoder')

def main():
 prov=load(ROOT/'PROVENANCE.json');n=prov['n'];comp=load(ROOT/'COMPARISON.json')
 if '--prepare-receipt'not in sys.argv:
  seen=set()
  for line in (ROOT/'SHA256SUMS').read_text().splitlines():
   digest,name=line.split('  ',1);p=ROOT/name;assert p.is_file()and sha(p)==digest,name;seen.add(name)
  actual={str(p.relative_to(ROOT))for p in ROOT.rglob('*')if p.is_file()and '__pycache__'not in p.parts and p.name!='SHA256SUMS'}
  assert actual==seen,'Unlisted or missing package files'
 new=load(ROOT/f'n{n}.cert.json');old=load(ROOT/f'n{n}-previous-submission.cert.json')
 assert sha(ROOT/f'n{n}.cert.json')==prov['banked_certificate_sha256']==comp['new_certificate_sha256']
 assert sha(ROOT/f'n{n}-previous-submission.cert.json')==comp['previous_submission_sha256']
 assert new['n']==old['n']==n
 results={'n':n,'new':verify_geometry(new),'previous_submission':verify_geometry(old)}
 S=Q(new['s_exact']);oldS=Q(old['s_exact']);assert S<oldS and Q(comp['gain_exact'])==oldS-S
 assert Q(comp['new_safe_bound_40_decimals'])>=S and Q(comp['new_safe_bound_40_decimals'])-S<Q(1,10**40)
 # A touching wall forces q>=1 for common centre-and-container scaling;
 # old geometry is valid, so its exact minimum common dilation is1.
 typ,i,k=comp['old_touching_wall_proof'];assert typ=='wall';x,y,t=map(Q,old['squares'][i]);f=basis(t);h=sum(map(abs,f[0]))/2
 assert [x,oldS-x,y,oldS-y][k]==h
 results['previous_common_dilation_minimum']='1'
 results['negative_controls']={k:negative(new,k)for k in['duplicate','outside']}
 native=load(ROOT/f'pingyou-n{n}-rational.yaml');conversion=check_identity(new,native)
 saved=load(ROOT/'native/conversion-check.json');replay=load(ROOT/'native/native-replay.json');yh=sha(ROOT/f'pingyou-n{n}-rational.yaml')
 assert saved['valid']and saved['source_sha256']==sha(ROOT/f'n{n}.cert.json')and saved['witness_sha256']==yh==replay['witness_sha256']
 assert native['witness']['certificate']['credits']==prov['credits']==load(ROOT/'native/credits.json')
 assert (ROOT/native['witness']['source']['path']).resolve()==(ROOT/f'n{n}.cert.json').resolve()
 manifest=load(ROOT/'native/upstream-source-manifest.json');assert sha(ROOT/'native/upstream-source-manifest.json')==replay['upstream_source_manifest_sha256']
 assert replay['valid']and replay['exact_result_agreement']and replay['source_commit']==manifest['commit']
 for f in manifest['files']:assert sha(ROOT/'native/upstream'/f['path'])==f['sha256']
 for name in['native_replay','upstream_independent_checker']:
  r=replay[name];assert r['verification_passed']and r['n']==n and r['pairs_tested']==n*(n-1)//2 and Q(r['side'])==S
 results['conversion']=conversion;results['native_reports_bound']=True
 # Preserve the original inherited inventory and saved equation subsets.
 inv=load(ROOT/'construction/inherited/INHERITED-SYSTEM.json');assert inv['n']==n and sha(ROOT/'construction/affine-input.cert.json')==inv['source_sha256']
 allowed={tuple(c)for c in inv['contact_equations']};attempts=[]
 for p in sorted((ROOT/'construction/inherited/closure100').glob('attempt-*')):
  a=load(p/'EQUATIONS-BEFORE-SOLVE.json');st=load(p/'pre-kkt-state.json');assert a['source_inventory_sha256']==sha(ROOT/'construction/inherited/INHERITED-SYSTEM.json')
  assert a['equations']==st['equations']and all(tuple(e)in allowed for e in a['equations']);attempts.append(len(a['equations']))
 results['declared_inherited_equations']=len(allowed);results['recorded_attempt_equation_counts']=attempts
 if n==146:
  raw=load(ROOT/'construction/inherited/raw.cert.json');assert Q(raw['s_exact'])==S and raw['squares']==new['squares'];results['raw_rational_geometry_already_valid']=True
 if n==261:
  source=load(ROOT/'construction/centre-input.cert.json');results['intermediate']=verify_geometry(source);results['support_word_replay']=verify_support_word(source,new)
  assert Q(comp['gain_vs_intermediate_exact'])==Q(source['s_exact'])-S>0
 results['valid']=True;results['certificate_sha256']=sha(ROOT/f'n{n}.cert.json');results['side_exact']=str(S)
 print(json.dumps(results,indent=2))
 return results

if __name__=='__main__':main()
