"""Independent rational polygon-intersection audit, not the SAT checker.

Build exact four-vertex squares, intersect candidate overlapping bounding-box
pairs by Sutherland-Hodgman clipping, and reject positive intersection area.
Also reconstruct the full certificate as a multiset from the 88 primitive.
"""
from fractions import Fraction as Q
from collections import Counter
from pathlib import Path
import json,time,hashlib
P=Path(__file__).resolve().parent

def vertices(s):
 x,y,t=s;den=1+t*t;c=(1-t*t)/den;si=2*t/den
 return [(x+(a*c-b*si)/2,y+(a*si+b*c)/2) for a,b in [(-1,-1),(1,-1),(1,1),(-1,1)]]
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def intersection_area(a,b):
 poly=a
 for k in range(4):
  u,v=b[k],b[(k+1)%4];out=[]
  if not poly:break
  last=poly[-1];fl=cross(u,v,last)
  for cur in poly:
   fc=cross(u,v,cur)
   if (fc>=0)!=(fl>=0):
    ratio=fl/(fl-fc);out.append((last[0]+ratio*(cur[0]-last[0]),last[1]+ratio*(cur[1]-last[1])))
   if fc>=0:out.append(cur)
   last,fl=cur,fc
  poly=out
 if len(poly)<3:return Q(0)
 return abs(sum(poly[k][0]*poly[(k+1)%len(poly)][1]-poly[k][1]*poly[(k+1)%len(poly)][0] for k in range(len(poly))))/2
def audit(cert):
 L=Q(cert['s_exact']);S=[tuple(map(Q,z)) for z in cert['squares']];V=[vertices(z) for z in S]
 assert len(S)==cert['n']
 for p in V:
  # The edge-length and signed-area tests independently enforce the unit-square
  # decoder, beyond accepting rational t as a rotation parametrization.
  assert all(0<=z<=L for xy in p for z in xy)
  assert all(sum((p[(k+1)%4][a]-p[k][a])**2 for a in range(2))==1 for k in range(4))
  assert sum(p[k][0]*p[(k+1)%4][1]-p[k][1]*p[(k+1)%4][0] for k in range(4))==2
 B=[(min(x for x,y in p),max(x for x,y in p),min(y for x,y in p),max(y for x,y in p)) for p in V]
 pairs=0;clipped=0;touching=0
 for i in range(len(S)):
  for j in range(i):
   pairs+=1;a,b=B[i],B[j]
   if a[1]<=b[0] or b[1]<=a[0] or a[3]<=b[2] or b[3]<=a[2]:continue
   clipped+=1;area=intersection_area(V[i],V[j]);assert area==0,(i,j,str(area));touching+=1
 return {'valid':True,'n':len(S),'pairs_checked':pairs,'pairs_exact_polygon_clipped':clipped,'nonpositive_intersection_areas':touching},S,L

