from pathlib import Path
import hashlib,json,os,subprocess,sys,urllib.request
P=Path(__file__).resolve().parent
dest=P/'reconstruction';src=dest/'upstream';src.mkdir(parents=True,exist_ok=True)
for name,row in json.loads((P/'source-manifest.json').read_text()).items():
 raw=urllib.request.urlopen(row['url']).read()
 if hashlib.sha256(raw).hexdigest()!=row['sha256']:raise ValueError('Upstream hash mismatch '+name)
 (src/name).write_bytes(raw)
env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
subprocess.run([sys.executable,str(src/'exactsolve.py'),str(P/'evidence/source160.txt'),'--dps','140','--eps','1e-80','--out',str(dest/'output')],env=env,check=True)
print('Compare the resulting exact certificate with evidence/source160.cert and rerun exact verification. Numerical pivot choices can depend on scientific-library versions; the retained rational witness is authoritative.')
