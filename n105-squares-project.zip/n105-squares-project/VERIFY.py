from pathlib import Path
from fractions import Fraction as F
import copy,hashlib,json,sys
from exact_sat import exact_check
from exact_polygon import audit
P=Path(__file__).resolve().parent
def require(c,m):
 if not c:raise ValueError(m)
require(__debug__,'Run without -O; the independent polygon checker contains assertions.')
for line in (P/'SHA256SUMS').read_text().splitlines():
 h,name=line.split('  ',1);require(hashlib.sha256((P/name).read_bytes()).hexdigest()==h,'Hash mismatch: '+name)
new=json.loads((P/'n105.cert.json').read_text());old=json.loads((P/'n105-prior.cert.json').read_text())
reports={}
for label,c in [('new',new),('prior',old)]:
 require(c['n']==105 and len(c['squares'])==105,'Wrong count')
 a=exact_check(c);b=audit(c)[0]
 require(a['valid'] and b['valid'] and a['pairs_checked']==5460 and b['pairs_checked']==5460,'Geometry failure')
 reports[label]={'exact_vertex_sat':a,'exact_polygon':b}
lo=(F(old['s_exact'])-F(1,10**30))/(1+F(1,10**20))
hi=F(old['s_exact'])/(1+F(1,10**20))
require(F(new['s_exact'])<lo<hi<F(old['s_exact']),'Not a strict source-design improvement')
cmp=json.loads((P/'COMPARISON.json').read_text())
require(F(cmp['candidate_side'])==F(new['s_exact']) and F(cmp['prior_certificate_side'])==F(old['s_exact']),'Comparison geometry binding mismatch')
require(F(cmp['source_design_strict_lower'])==lo and F(cmp['source_design_upper'])==hi,'Source interval mismatch')
sys.path.insert(0,str(P/'native'))
from convert_witness import check_identity
reports['native_roundtrip']=check_identity(new,json.loads((P/'pingyou-n105-rational.yaml').read_text()))
bad=copy.deepcopy(new);bad['squares'][1]=bad['squares'][0][:]
require(not exact_check(bad)['valid'],'Duplicate negative control accepted')
try:audit(bad)
except AssertionError:pass
else:raise ValueError('Polygon duplicate negative control accepted')
bad=copy.deepcopy(new);bad['squares'][0][0]='-2'
require(not exact_check(bad)['valid'],'Outside negative control accepted')
try:audit(bad)
except AssertionError:pass
else:raise ValueError('Polygon outside negative control accepted')
reports['negative_controls']='Both exact checkers reject duplicate and outside squares'
reports['all_valid']=True
print(json.dumps(reports,indent=2))
