302 unit squares: exact feasible upper bound
New construction: PingYou Ltd

s(302) <= 22337844230223278442299999/1250000000000000000000000
        = 17.8702753841786227538399992
        < 17.870275384179 (upward-rounded reporting bound).

Extract the archive and enter n302-squares-project. With Python 3.10+:
  python3 VERIFY.py
Run without -O. This default replay uses only the standard library.

The package verifies all 302 unit squares, all 1208 wall conditions and all
45451 unordered pairs. Every square is strictly inside the container and
every pair is strictly separated. Minimum wall clearance is 5e-12; minimum
unit-axis separating gap is approximately 9.996640888046576e-12.
There are three orientations modulo90 degrees: 254 upright squares and two
tilting populations of24 each.

The finite rational guard is included. The exact construction replay retains
the complete physical-owner decoder, cubic-derived coherent frames, explicit
final rational center table and recomputed guard. It reproduces all exact
coordinates; it does not rerun exploratory owner selection or the floating
linear solve. See construction/ for the argument, data and scope.

The independent exhaustive checker, Evan Daniel's unchanged exact SAT and
polygon-intersection checkers all accept the witness. The native Witness/v2
conversion preserves exact geometry. Two additional unchanged Squares Project
implementations at074ac28d4ceb9a1897303f936d794771cfc6a7bd also pass.
Their receipt, source subset, licenses and replay instructions are in native/.
That optional native replay has the upstream Python dependencies; VERIFY.py
does not need them. These checks are not independent human audits and do not
establish local or global optimality.

The strongest public comparison found on12 October2026 is T-146:
558500932783786874181638432249/31250000000000000000000000000
=17.872029849081179973812429831968.
The new exact side is smaller by0.001754464902557219972430631968.
The dated comparison uses the exact certificate, not a rounded display.
See evidence/comparison.json for pinned URLs and source revisions. No stronger
N302 or direct deletion bound fromN303..319 was found. Counts320 and above are
excluded for direct deletion by area. No claim excludes unknown unpublished work.

Credit and lineage
PingYou Ltd: new N302 construction.
Ryan Xu: underlying N70 construction, announced at
https://github.com/jlevy/squares/issues/432 .
Evan Daniel: retained exact N70 source and prior N302 regularization.
Nate Chaoweeraprasit (SQUISH): prior N302 construction, issue481.
Joshua Levy and the Squares Project: native format and upstream checking tools.
Upstream sources and licenses are retained alongside the relevant files.
No new license grant is inferred for unrelated third-party material.

The portable certificate drops nongeometric internal metadata only.
evidence/document-binding.json binds it to the original reviewed file.
All exact coordinate/orientation strings, ordering, count and side are unchanged.
The comparison PDF and SVG are illustrations; the rational certificate is the
mathematical witness. Submission does not imply maintainer acceptance.
