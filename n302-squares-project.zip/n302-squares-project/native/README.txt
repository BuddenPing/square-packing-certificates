N302 exact rational Witness/v2 conversion and native verification
================================================================

New construction: PingYou Ltd.
Underlying N70 contact skeleton: Ryan Xu.
Retained source certificate custody: Evan Daniel.

The native witness represents the same302 unit squares at exact side
22337844230223278442299999 / 1250000000000000000000000
=17.8702753841786227538399992, safely rounded upward as17.870275384179.
This is a complete feasible upper bound, with no optimality claim.

Source and conversion
---------------------
pingyou-n302-rational.yaml uses the current packing.squares:Witness/v2 schema,
rational corners, lower-left origin, x-right/y-up coordinates, and unit square
size. Its contents are JSON syntax, accepted as YAML. All source coordinates,
side length and square ordering are preserved. For source pose[x,y,t]:

c=(1-t*t)/(1+t*t), s=2*t/(1+t*t),
corner(a,b)=(x+(a*c-b*s)/2, y+(a*s+b*c)/2),
where(a,b)=(-1,-1),(1,-1),(1,1),(-1,1).

The standard-library converter uses exact fractions. The --check mode recovers
each source center as the corner mean and t=s/(1+c) from the first edge, and
compares all302 poses exactly. It checks unit edges and containment. This
comparison is geometric, so removal of nongeometric source metadata does not
alter its result. conversion-check.json records the original input hash;
source-binding.json also records a canonical geometry hash. A final public
release can bind its metadata-only source rewrite separately.

From a release root containing native/ and evidence/:

python3 -B native/convert_witness.py evidence/packing.cert.json native/pingyou-n302-rational.yaml --check

Generation mode omits --check and requires a new output path; it refuses to
overwrite an existing witness.

Squares Project verification
----------------------------
Upstream repository: https://github.com/jlevy/squares
Pinned current revision:074ac28d4ceb9a1897303f936d794771cfc6a7bd
Retrieved12 October2026. upstream-source-manifest.json gives immutable URLs
and SHA-256 values for every retained upstream file. The core verifier,
independent rational-corner checker, schema and license are unchanged upstream
bytes. The upstream/ directory is a focused source subset, not a full checkout.

replay_upstream.py loads and schema-validates the witness, invokes
sqpack.witness.exact_verify (the functions used by packing-witness verify),
and invokes the separate check_rational_witness_independent checker. It checks
all retained source hashes before importing upstream code. The supplied schema
must also match its pinned hash. It requires both verifiers to report all302
squares and45,451 pairs, with identical exact clearances and no failures.
This is a native entry-point replay, not a full upstream repository test run
or a maintainer endorsement.

Use Python3.14 with mpmath1.4.1, PyYAML6.0.3, jsonschema4.26.0 and strif3.1.0
and their dependencies. From the release root:

python3 -B native/replay_upstream.py --witness native/pingyou-n302-rational.yaml

The wrapper defaults to the bundled upstream source subset. Alternatively,
pass --checkout /path/to/squares to use a full checkout at the pinned revision.
The equivalent official command, from that checkout's packing/ directory with
its dependencies installed, is:

uv run --frozen packing-witness verify /path/to/release/native/pingyou-n302-rational.yaml --json

Licensing and upstream credit
-----------------------------
The unchanged upstream license is included as UPSTREAM-LICENSE.txt and also
upstream/LICENSE. Upstream source code is MIT licensed. The schema is covered
by the upstream repository's CC BY4.0 grant. Credit for the upstream software
and schema: Joshua Levy, the squares project (https://github.com/jlevy/squares).
No new license grant is inferred for unrelated third-party material.
