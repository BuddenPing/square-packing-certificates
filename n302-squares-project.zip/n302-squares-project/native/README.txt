N302 refined exact rational Witness/v2

Construction credit: PingYou Ltd.
Underlying N70 contact skeleton: Ryan Xu.
Retained N70 source certificate: Evan Daniel.

This witness contains exactly 302 unit squares with rational corners at side
1787027538273375975382555057/100000000000000000000000000
= 17.87027538273375975382555057. A safe upward display is 17.870275382734.
It is a feasible upper bound; no local or global optimality is claimed.

The source snapshot's SHA-256 is 1215eec89740633ff8a0d806f746fcb4f56e402d97364b59394ca1c3bf78a5f0.
The witness's SHA-256 is 542974911e45a4dec335d07ad072ab7a86ab5b0d7ab84ecb720dab8253b2aa38.
source-binding.json also records a canonical geometry digest. The source path
in the witness is ../evidence/packing.cert.json for the final package layout.

Exact conversion
The standard-library converter maps each [x,y,t] using
(c,s)=((1-t*t)/(1+t*t),2*t/(1+t*t)) and the four signed half-edge sums.
Its --check mode recovers every centre and half-angle, checks unit edges and
containment, and preserves square order. conversion-check.json is a fresh
receipt for this refined certificate. It is not a pairwise feasibility check.

From a release root with native/ and evidence/:
python3 -B native/convert_witness.py evidence/packing.cert.json native/pingyou-n302-rational.yaml --check

Pinned upstream verification
The retained upstream subset is unchanged from jlevy/squares commit
074ac28d4ceb9a1897303f936d794771cfc6a7bd. The source manifest binds every retained file,
including the schema and license. This is also the current upstream HEAD
at the public check on 12 October 2026. The wrapper verifies all hashes before
importing. Both unchanged implementations passed 302 squares and 45,451 pairs:
sqpack.witness.exact_verify and devtools.check_rational_witness_independent.
They report identical exact margins and no failures.
Wall clearance: 1/200000000000.
First route: 7.760s; second: 3.739s.
See native-replay.json for full exact results and dependencies.

Reproduce with Python 3.14 and the pinned dependencies:
uv run --no-project --python 3.14 --with mpmath==1.4.1 --with PyYAML==6.0.3 --with jsonschema==4.26.0 --with strif==3.1.0 python -B native/replay_upstream.py --witness native/pingyou-n302-rational.yaml

Alternatively
install the listed dependencies into a Python 3.14 environment and run the
wrapper directly. It defaults to native/upstream, a focused source subset.
A full checkout at the pinned revision may be supplied with --checkout.
The corresponding official command from its packing/ directory is:
uv run --frozen packing-witness verify /path/to/native/pingyou-n302-rational.yaml --json

This run used unchanged verifier entry points. It was not a full repository
test run or maintainer endorsement. All checkers consume the same rational
geometry. These are not independent human audits or optimality proofs.

Upstream software and schema credit: Joshua Levy, the squares project,
https://github.com/jlevy/squares. The unchanged upstream license is retained
as UPSTREAM-LICENSE.txt and upstream/LICENSE.
