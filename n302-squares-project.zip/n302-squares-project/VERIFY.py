#!/usr/bin/env python3
"""Verify the complete released N302 witness with Python standard library only."""
from pathlib import Path
import hashlib,json,subprocess,sys,tempfile
root=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Run without -O')
def run(script,*args,ok=True):
 p=subprocess.run([sys.executable,'-B',str(root/script),*[str(x) for x in args]],capture_output=True,text=True)
 if (p.returncode==0)!=ok:raise RuntimeError(p.stdout+p.stderr)
 return p.stdout
for line in (root/'SHA256SUMS').read_text().splitlines():
 expected,name=line.split('  ',1)
 if hashlib.sha256((root/name).read_bytes()).hexdigest()!=expected:raise ValueError('Hash mismatch: '+name)
cert=root/'evidence/packing.cert.json'
g=json.loads(run('checkers/verify_n302.py',cert))
assert g['valid'] and g['pairs_checked']==45451 and g['wall_constraints_checked']==1208
assert g['all_pairs_have_strict_separating_gap']
for name in ['verify_cert.py','verify_cert2.py']:
 run('checkers/'+name,root/'evidence/n302.cert')
 run('checkers/'+name,root/'evidence/prior-n302.cert')
run('construction/reproduce.py','--certificate',cert)
run('native/convert_witness.py',cert,root/'native/pingyou-n302-rational.yaml','--check')
with tempfile.TemporaryDirectory() as d:
 d=Path(d)
 for name in ['duplicate_square','outside_wall']:
  v=json.loads(cert.read_text())
  if name=='duplicate_square':v['squares'][1]=v['squares'][0][:]
  else:v['squares'][0][0]='-1'
  a=d/(name+'.json');a.write_text(json.dumps(v))
  b=d/(name+'.cert');b.write_text(str(v['n'])+' '+v['s_exact']+'\n'+'\n'.join(' '.join(x) for x in v['squares'])+'\n')
  run('checkers/verify_n302.py',a,ok=False)
  for check in ['verify_cert.py','verify_cert2.py']:run('checkers/'+check,b,ok=False)
print('PASS: file hashes; 302 unit squares; 1208 walls; 45451 pairs; three exact geometry checks; prior certificate; exact construction replay; lossless native conversion; duplicate and outside-wall rejection controls.')
print('For the additional upstream native checks, see native/README.txt and native/native-replay.json.')
