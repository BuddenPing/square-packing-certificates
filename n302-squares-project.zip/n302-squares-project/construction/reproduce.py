"""Reconstruct the refined N302 rational witness; Python standard library only.

The input is an explicit rational construction table, not an optimization seed.
No optimizer, network access, or external repository is needed. The optional
--certificate argument checks exact geometry against a separately supplied file.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import argparse
import gzip
import hashlib
import json

HERE = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(d):
    return {"n": d["n"], "s_exact": str(F(d["s_exact"])),
            "squares": [[str(F(v)) for v in row] for row in d["squares"]]}


def digest(d):
    data = json.dumps(canonical(d), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(data.encode()).hexdigest()


def basis(t):
    c, s = (1-t*t)/(1+t*t), 2*t/(1+t*t)
    require(c*c+s*s == 1, "unit-square identity")
    return (c, s), (-s, c)


def dot(a, b):
    return a[0]*b[0]+a[1]*b[1]


def check_geometry(d):
    """All walls and all unordered pairs; exact separating-axis arithmetic."""
    rows = [[F(v) for v in row] for row in d["squares"]]
    require(len(rows) == d["n"], "square count")
    side = F(d["s_exact"])
    axes = [basis(t) for x, y, t in rows]
    radii = [(abs(u[0])+abs(u[1]))/2 for u, v in axes]
    pairs, bounding_box_pairs = 0, 0
    for i, (x, y, t) in enumerate(rows):
        h = radii[i]
        require(min(x, y, side-x, side-y) >= h, "wall violation at owner %d" % i)
        for j in range(i):
            pairs += 1
            delta = (x-rows[j][0], y-rows[j][1])
            if max(abs(delta[0]), abs(delta[1])) >= h+radii[j]:
                bounding_box_pairs += 1
                continue
            separated = False
            for normal in (*axes[i], *axes[j]):
                radius = sum(abs(dot(b, normal)) for b in (*axes[i], *axes[j]))/2
                if abs(dot(delta, normal)) >= radius:
                    separated = True
                    break
            require(separated, "overlap at owners %d,%d" % (j, i))
    return {"valid": True, "unit_squares": len(rows),
            "wall_inequalities": 4*len(rows), "pairs": pairs,
            "pairs_separated_by_axis_bounding_boxes": bounding_box_pairs}


def required_guard(side, rows):
    """Compute the exact smallest common center/host dilation for this table.

    Only dilation factors >=1 are considered; each square retains unit side.
    A pair needs the minimum required factor over its four edge normals.
    """
    required = F(1)
    axes = [basis(t) for x, y, t in rows]
    radii = [(abs(u[0])+abs(u[1]))/2 for u, v in axes]
    for i, (x, y, t) in enumerate(rows):
        h = radii[i]
        for distance in [x, y, side-x, side-y]:
            require(distance > 0, "nonpositive wall distance before guard")
            required = max(required, h/distance)
        for j in range(i):
            delta = (x-rows[j][0], y-rows[j][1])
            if max(abs(delta[0]), abs(delta[1])) >= h+radii[j]:
                continue
            options = []
            for normal in (*axes[i], *axes[j]):
                distance = abs(dot(delta, normal))
                if distance:
                    radius = sum(abs(dot(b, normal)) for b in (*axes[i], *axes[j]))/2
                    options.append(radius/distance)
            require(options, "coincident centers")
            required = max(required, min(options))
    return required


def check_signed_word(rows, word):
    """Check the fixed signed separator for every unordered pair exactly."""
    cache = {}
    frames = {row[2]: basis(row[2]) for row in rows}
    position, minimum = 0, None
    for i in range(len(rows)):
        for j in range(i+1, len(rows)):
            digit = int(word[position])
            axis_index, sign = digit//2, (1 if digit % 2 else -1)
            key = (rows[i][2], rows[j][2], axis_index)
            if key not in cache:
                axes = (*frames[rows[i][2]], *frames[rows[j][2]])
                normal = axes[axis_index]
                radius = sum(abs(dot(normal, axis)) for axis in axes)/2
                cache[key] = normal, radius
            normal, radius = cache[key]
            delta = (rows[j][0]-rows[i][0], rows[j][1]-rows[i][1])
            gap = sign*dot(normal, delta)-radius
            require(gap >= 0, "fixed separator violation at owners %d,%d" % (i, j))
            minimum = gap if minimum is None else min(minimum, gap)
            position += 1
    require(position == len(word), "signed word length")
    return {"pairs": position, "all_fixed_separators_valid": True,
            "minimum_signed_gap": str(minimum)}


def reconstruct():
    recipe = json.loads((HERE/"rational_recipe.json").read_text())
    raw = (HERE/"previous-n302.cert.json").read_bytes()
    require(hashlib.sha256(raw).hexdigest() == recipe["previous_certificate_sha256"],
            "previous certificate hash")
    previous = json.loads(raw)
    old_rows = [[F(v) for v in row] for row in previous["squares"]]
    require(previous["n"] == len(old_rows) == recipe["n"] == 302, "owner count")
    require(recipe["source_owner_order"] == [0, 34]+[i for i in range(302) if i not in [0, 34]],
            "owner correspondence")

    # Verify the previously derived cubic and the inherited coherent frames.
    require(recipe["frame_polynomial_coefficients_descending"] == [2, -3, -2, 1],
            "frame polynomial")
    low, high = map(F, recipe["frame_root_interval"])
    polynomial = lambda t: 2*t**3-3*t*t-2*t+1
    require(0 < low < high < F(2, 5), "root interval")
    require(polynomial(low) > 0 > polynomial(high), "root endpoint signs")
    midpoint = (low+high)/2
    require(Counter(t for x, y, t in old_rows) ==
            {F(0): 253, F(-1): 1, -midpoint: 24, (midpoint-1)/(midpoint+1): 24},
            "previous coherent frames")

    # Rebuild the complete predecessor used to select the signed pair word.
    # Keep two opposite upright corner owners. Reflect every non-corner
    # previous owner across the anti-diagonal, then translate the image.
    guard = F(recipe["center_guard"])
    old_side = F(previous["s_exact"])
    predecessor_side = F(recipe["predecessor_side_exact"])
    precursor_rows = [[guard/2, guard/2, F(0)],
                      [predecessor_side-guard/2, predecessor_side-guard/2, F(-1)]]
    precursor_rows += [[old_side-y, predecessor_side-x, -t]
                      for i, (x, y, t) in enumerate(old_rows) if i not in [0, 34]]
    precursor = {"n": 302, "s_exact": str(predecessor_side),
                 "squares": [[str(v) for v in row] for row in precursor_rows]}
    require(digest(precursor) == recipe["predecessor_geometry_sha256"], "predecessor identity")
    raw_word = (HERE/"signed_pair_word.txt.gz").read_bytes()
    require(hashlib.sha256(raw_word).hexdigest() == recipe["signed_pair_word_compressed_sha256"],
            "signed word hash")
    word = gzip.decompress(raw_word).decode()
    require(len(word) == 302*301//2 and all(c in "01234567" for c in word), "signed word encoding")
    predecessor_word_check = check_signed_word(precursor_rows, word)

    # Reconstruct the recorded rational realization; no linear solve occurs.
    denominator = int(recipe["coordinate_denominator_before_guard"])
    require(denominator > 0, "coordinate denominator")
    numerators = recipe["centers_before_guard_numerators"]
    require(len(numerators) == 302, "coordinate count")
    rows = [[F(x, denominator), F(y, denominator), prior[2]]
            for (x, y), prior in zip(numerators, precursor_rows)]
    side = F(recipe["side_before_guard"])
    needed = required_guard(side, rows)
    recomputed_guard = next(g for exponent in [11, 10, 9, 8, 7]
                            if (g := 1+F(1, 10**exponent)) >= needed)
    require(guard == recomputed_guard, "guard recomputation")
    final_rows = [[x*guard, y*guard, t] for x, y, t in rows]
    result = {"n": 302, "s_exact": str(side*guard),
              "squares": [[str(v) for v in row] for row in final_rows]}
    require(digest(result) == recipe["final_geometry_sha256"], "final geometry identity")
    require(final_rows[0][:2] == [guard/2, guard/2] and
            final_rows[1][:2] == [side*guard-guard/2, side*guard-guard/2], "corner marks")
    require(F(result["s_exact"]) < old_side, "strict improvement")
    report = {"valid": True, "previous_geometry": check_geometry(previous),
              "predecessor_owner_decoder_identity": True,
              "predecessor_geometry": check_geometry(precursor),
              "predecessor_signed_word": predecessor_word_check,
              "cubic_root_interval_verified": True,
              "inherited_coherent_frame_counts": [254, 24, 24],
              "guard_recomputed_exactly": str(guard),
              "guard_multiplier_unchanged_from_previous_release": guard == F(100000000001, 100000000000),
              "final_geometry": check_geometry(result),
              "final_signed_word": check_signed_word(final_rows, word),
              "four_corner_coordinate_marks_verified": True,
              "side_exact": result["s_exact"],
              "improvement_exact": str(old_side-F(result["s_exact"])),
              "geometry_sha256": digest(result),
              "scope": "Exact explicit-table replay of a coordinate refinement at the inherited cubic frame; no optimization or optimality claim."}
    return result, report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--certificate", type=Path, help="Compare a supplied certificate's exact geometry")
    parser.add_argument("--output", type=Path, help="Write the reconstructed portable JSON certificate")
    parser.add_argument("--receipt", type=Path, help="Write the replay/check receipt")
    args = parser.parse_args()
    certificate, report = reconstruct()
    if args.certificate:
        supplied = json.loads(args.certificate.read_text())
        require(canonical(supplied) == canonical(certificate), "supplied certificate mismatch")
        report["supplied_certificate_matches"] = True
    if args.output:
        args.output.write_text(json.dumps(certificate, indent=2)+"\n")
    if args.receipt:
        args.receipt.write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()


