"""Reconstruct the released N302 rational witness; Python standard library only.

The input is an explicit rational construction table, not an optimization seed.
No optimizer, network access, or external repository is needed. The optional
--certificate argument checks exact geometry against a separately supplied file.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import argparse
import gzip
import hashlib
import json

HERE = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(d):
    return {"n": d["n"], "s_exact": str(F(d["s_exact"])),
            "squares": [[str(F(v)) for v in row] for row in d["squares"]]}


def digest(d):
    data = json.dumps(canonical(d), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(data.encode()).hexdigest()


def basis(t):
    c, s = (1-t*t)/(1+t*t), 2*t/(1+t*t)
    require(c*c+s*s == 1, "unit-square identity")
    return (c, s), (-s, c)


def dot(a, b):
    return a[0]*b[0]+a[1]*b[1]


def check_geometry(d):
    """All walls and all unordered pairs; exact separating-axis arithmetic."""
    rows = [[F(v) for v in row] for row in d["squares"]]
    require(len(rows) == d["n"], "square count")
    side = F(d["s_exact"])
    axes = [basis(t) for x, y, t in rows]
    radii = [(abs(u[0])+abs(u[1]))/2 for u, v in axes]
    pairs, bounding_box_pairs = 0, 0
    for i, (x, y, t) in enumerate(rows):
        h = radii[i]
        require(min(x, y, side-x, side-y) >= h, "wall violation at owner %d" % i)
        for j in range(i):
            pairs += 1
            delta = (x-rows[j][0], y-rows[j][1])
            if max(abs(delta[0]), abs(delta[1])) >= h+radii[j]:
                bounding_box_pairs += 1
                continue
            separated = False
            for normal in (*axes[i], *axes[j]):
                radius = sum(abs(dot(b, normal)) for b in (*axes[i], *axes[j]))/2
                if abs(dot(delta, normal)) >= radius:
                    separated = True
                    break
            require(separated, "overlap at owners %d,%d" % (j, i))
    return {"valid": True, "unit_squares": len(rows),
            "wall_inequalities": 4*len(rows), "pairs": pairs,
            "pairs_separated_by_axis_bounding_boxes": bounding_box_pairs}


def required_guard(side, rows):
    """Compute the exact smallest common center/host dilation for this table.

    Only dilation factors >=1 are considered; each square retains unit side.
    A pair needs the minimum required factor over its four edge normals.
    """
    required = F(1)
    axes = [basis(t) for x, y, t in rows]
    radii = [(abs(u[0])+abs(u[1]))/2 for u, v in axes]
    for i, (x, y, t) in enumerate(rows):
        h = radii[i]
        for distance in [x, y, side-x, side-y]:
            require(distance > 0, "nonpositive wall distance before guard")
            required = max(required, h/distance)
        for j in range(i):
            delta = (x-rows[j][0], y-rows[j][1])
            if max(abs(delta[0]), abs(delta[1])) >= h+radii[j]:
                continue
            options = []
            for normal in (*axes[i], *axes[j]):
                distance = abs(dot(delta, normal))
                if distance:
                    radius = sum(abs(dot(b, normal)) for b in (*axes[i], *axes[j]))/2
                    options.append(radius/distance)
            require(options, "coincident centers")
            required = max(required, min(options))
    return required


def reconstruct():
    recipe = json.loads((HERE/"rational_recipe.json").read_text())
    raw = (HERE/"source70.cert.gz").read_bytes()
    require(hashlib.sha256(raw).hexdigest() == recipe["source70_compressed_sha256"],
            "source certificate hash")
    lines = [line.split() for line in gzip.decompress(raw).decode().splitlines()
             if line.strip() and not line.startswith("#")]
    n, side = lines[0]
    source = {"n": int(n), "s_exact": side, "squares": lines[1:]}
    require(source["n"] == len(source["squares"]) == 70, "source count")
    source_side = F(side)
    source_rows = [[F(v) for v in row] for row in source["squares"]]

    # Decode each physical source/grid owner, in constructor order.
    precursor = []
    for patch in recipe["patches"]:
        a, b = patch["station"]
        require(patch["flip"] in [0, 1], "reflection flag")
        for owner in patch["source_owners"]:
            x, y, t = source_rows[owner]
            if patch["flip"]:
                (c, s), _ = basis(t)
                x, y, t = source_side-y, source_side-x, -c/(1-s)
            precursor.append([x+a, y+b, t])
    require(len(precursor) == 50, "source patch count")
    bank_counts = Counter()
    for bank, i, low, high in recipe["bank_intervals"]:
        require(bank in [0, 1] and low <= high, "bank interval")
        for j in range(low, high+1):
            phase = source_side-8
            precursor.append([F(i)+F(1, 2)+(phase if bank else 0),
                              F(j)+F(1, 2)+(0 if bank else phase), F(0)])
            bank_counts[bank] += 1
    require(bank_counts == {0: 105, 1: 147}, "bank owner counts")
    g0 = F(recipe["precursor_center_guard"])
    precursor = [[g0*x, g0*y, t] for x, y, t in precursor]
    pre = {"n": 302, "s_exact": str((source_side+9)*g0),
           "squares": [[str(v) for v in row] for row in precursor]}
    require(digest(pre) == recipe["precursor_geometry_sha256"], "precursor decoder identity")

    # The cubic has one root in the supplied interval: endpoint signs differ,
    # and its derivative 6t^2-6t-2 is negative throughout (0,1).
    require(recipe["frame_polynomial_coefficients_descending"] == [2, -3, -2, 1],
            "frame polynomial")
    low, high = map(F, recipe["frame_root_interval"])
    polynomial = lambda t: 2*t**3-3*t*t-2*t+1
    require(0 < low < high < F(2, 5), "root interval")
    require(polynomial(low) > 0 > polynomial(high), "root endpoint signs")
    midpoint = (low+high)/2
    frames = [t if t in [0, -1] else
              (-midpoint if abs(t) < F(2, 5) else (midpoint-1)/(midpoint+1))
              for x, y, t in precursor]
    require(Counter(frames) == {F(0): 253, F(-1): 1, -midpoint: 24,
                               (midpoint-1)/(midpoint+1): 24}, "coherent frames")

    denominator = int(recipe["coordinate_denominator_before_guard"])
    require(denominator > 0, "coordinate denominator")
    numerators = recipe["centers_before_guard_numerators"]
    require(len(numerators) == len(frames) == recipe["n"] == 302, "final owner count")
    rows = [[F(x, denominator), F(y, denominator), t]
            for (x, y), t in zip(numerators, frames)]
    side = F(recipe["side_before_guard"])
    needed = required_guard(side, rows)
    # This is the disclosed guard sequence used in the original construction.
    guard = next(g for exponent in [11, 10, 9, 8, 7]
                 if (g := 1+F(1, 10**exponent)) >= needed)
    require(guard == F(recipe["center_guard"]), "guard recomputation")
    result = {"n": 302, "s_exact": str(side*guard),
              "squares": [[str(x*guard), str(y*guard), str(t)] for x, y, t in rows]}
    require(digest(result) == recipe["final_geometry_sha256"], "final geometry identity")
    report = {"valid": True, "source_geometry": check_geometry(source),
              "precursor_owner_decoder_identity": True,
              "precursor_geometry": check_geometry(pre),
              "cubic_root_interval_verified": True,
              "coherent_frame_counts": [254, 24, 24],
              "guard_recomputed_exactly": str(guard),
              "final_geometry": check_geometry(result),
              "side_exact": result["s_exact"], "geometry_sha256": digest(result),
              "scope": "Exact explicit-table replay and geometry checks; no optimization or claim of optimality."}
    return result, report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--certificate", type=Path, help="Compare a supplied certificate's exact geometry")
    parser.add_argument("--output", type=Path, help="Write the reconstructed portable JSON certificate")
    parser.add_argument("--receipt", type=Path, help="Write the replay/check receipt")
    args = parser.parse_args()
    certificate, report = reconstruct()
    if args.certificate:
        supplied = json.loads(args.certificate.read_text())
        require(canonical(supplied) == canonical(certificate), "supplied certificate mismatch")
        report["supplied_certificate_matches"] = True
    if args.output:
        args.output.write_text(json.dumps(certificate, indent=2)+"\n")
    if args.receipt:
        args.receipt.write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
