#!/usr/bin/env python3
"""Fresh, exhaustive rational polygon/SAT audit of the frozen N302 certificate.

Python standard library only. No producer module is imported. No candidate
coordinate is edited. Every pair is tested using projections of reconstructed
quadrilateral vertices onto its four unit face normals; no broad-phase pruning.
Run: python3 -B verify_n302.py [packing.cert.json]
"""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal, localcontext, ROUND_CEILING
from collections import Counter
import argparse, hashlib, json, math, time


def unique_keys(pairs):
    out={}
    for k,v in pairs:
        if k in out:raise ValueError(f'Duplicate JSON key: {k}')
        out[k]=v
    return out


def dot(a,b):return a[0]*b[0]+a[1]*b[1]
def minus(a,b):return a[0]-b[0],a[1]-b[1]
def qstr(x):return str(x)

def audit(path):
    if not __debug__:
        raise RuntimeError('Run without -O: this verifier requires active assertions')
    started=time.perf_counter();raw=path.read_bytes()
    obj=json.loads(raw,object_pairs_hook=unique_keys)
    n=obj['n'];side=F(obj['s_exact']);poses=obj['squares']
    assert type(n) is int and n==302 and len(poses)==n
    assert side==F('22337844230223278442299999/1250000000000000000000000')
    squares=[];bases=[];orientation_keys=[];decoded=[]
    wall_constraints=[];edge_tests=0;orthogonality_tests=0
    for i,row in enumerate(poses):
        assert len(row)==3 and all(type(v) is str for v in row)
        x,y,t=map(F,row);decoded.append((x,y,t))
        den=1+t*t;c=(1-t*t)/den;s=2*t/den
        assert c*c+s*s==1
        corners=[(x+(a*c-b*s)/2,y+(a*s+b*c)/2)
                 for a,b in [(-1,-1),(1,-1),(1,1),(-1,1)]]
        assert len(set(corners))==4
        edges=[minus(corners[(k+1)%4],corners[k]) for k in range(4)]
        for k,e in enumerate(edges):
            assert dot(e,e)==1;edge_tests+=1
            assert dot(e,edges[(k+1)%4])==0;orthogonality_tests+=1
            assert edges[(k+2)%4]==(-e[0],-e[1])
        double_area=sum(corners[k][0]*corners[(k+1)%4][1]-corners[(k+1)%4][0]*corners[k][1] for k in range(4))
        assert double_area==2
        assert sum(p[0] for p in corners)/4==x and sum(p[1] for p in corners)/4==y
        walls=[min(p[0] for p in corners),side-max(p[0] for p in corners),
               min(p[1] for p in corners),side-max(p[1] for p in corners)]
        for w,gap in enumerate(walls):
            assert gap>=0,('wall',i,w,str(gap))
            wall_constraints.append((gap,i,w))
        squares.append(corners);bases.append((edges[0],edges[1]))
        # First-quadrant representative of square direction, modulo90 degrees.
        if c>0 and s>=0:a,b=c,s
        elif s>0 and c<=0:a,b=s,-c
        elif c<0 and s<=0:a,b=-c,-s
        else:a,b=-s,c
        assert a>0 and b>=0
        orientation_keys.append(b/a)
    assert len(set(decoded))==n
    assert len({tuple(sorted(poly)) for poly in squares})==n
    assert len({(x,y) for x,y,t in decoded})==n
    # Projection intervals are cached exactly for efficiency. Every candidate
    # separating axis for every pair is still evaluated, including distant pairs.
    axes=set(v for basis in bases for v in basis)
    intervals={axis:[(min(dot(p,axis) for p in poly),max(dot(p,axis) for p in poly)) for poly in squares] for axis in axes}
    # Cross-check every cached polygon projection against its center-support
    # formula. This is a second path for interval construction, not pair pruning.
    for axis in axes:
        for i,(x,y,t) in enumerate(decoded):
            center=dot((x,y),axis)
            radius=sum(abs(dot(v,axis)) for v in bases[i])/2
            assert intervals[axis][i]==(center-radius,center+radius)
    pair_min=None;pairs=0;touching=0
    for i in range(n):
        for j in range(i):
            best=None;best_axis=None
            for axis in (*bases[i],*bases[j]):
                amin,amax=intervals[axis][i];bmin,bmax=intervals[axis][j]
                gap=max(bmin-amax,amin-bmax)
                if best is None or gap>best:best,best_axis=gap,axis
            assert best>=0,('overlap',i,j,str(best))
            if best==0:touching+=1
            if pair_min is None or best<pair_min[0]:pair_min=(best,j,i,best_axis)
            pairs+=1
    assert pairs==n*(n-1)//2==45451
    assert len(wall_constraints)==4*n==1208
    wall_min=min(wall_constraints)
    counts=Counter(orientation_keys)
    with localcontext() as ctx:
        ctx.prec=100
        dec=lambda v:str(Decimal(v.numerator)/Decimal(v.denominator))
        result={
            'valid':True,'source_filename':path.name,'certificate_sha256':hashlib.sha256(raw).hexdigest(),
            'source_bytes':len(raw),'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'n':n,'unique_pose_triples':len(set(decoded)),
            'unique_centres':len({(x,y) for x,y,t in decoded}),
            'unique_physical_squares':len({tuple(sorted(poly)) for poly in squares}),
            'unit_square_shapes_verified':n,'unit_edge_identities_verified':edge_tests,
            'adjacent_edge_orthogonality_verified':orthogonality_tests,
            'unit_area_identities_verified':n,'side_exact':str(side),'side_decimal':dec(side),
            'side_upward_rounded_12_places':str((Decimal(side.numerator)/Decimal(side.denominator)).quantize(Decimal('0.000000000001'),rounding=ROUND_CEILING)),
            'wall_constraints_checked':len(wall_constraints),'pairs_checked':pairs,
            'all_pairs_have_strict_separating_gap':pair_min[0]>0,'touching_pairs':touching,
            'minimum_wall_clearance_exact':str(wall_min[0]),'minimum_wall_clearance_decimal':dec(wall_min[0]),
            'minimum_wall_square_index_zero_based':wall_min[1],
            'minimum_wall_name':['left','right','bottom','top'][wall_min[2]],
            'minimum_best_unit_axis_pair_gap_exact':str(pair_min[0]),
            'minimum_best_unit_axis_pair_gap_decimal':dec(pair_min[0]),
            'minimum_pair_indices_zero_based':list(pair_min[1:3]),
            'minimum_pair_axis':[str(v) for v in pair_min[3]],
            'literal_exact_orientations_mod_90':len(counts),
            'orientations':[{'slope_exact':str(k),'angle_degrees_for_display':math.degrees(math.atan(float(k))),'squares':v} for k,v in sorted(counts.items())],
            'normalization':'Unit edges and unit area proved directly from rational vertices; source metadata never supplies a scale factor to the verifier.',
            'method':'Exhaustive exact Fraction polygon projections/SAT on all four pair face normals; all cached intervals separately agree with exact center-support intervals; no producer code imported, no pair pruning.',
            'elapsed_seconds':time.perf_counter()-started,
        }
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('certificate',type=Path,nargs='?',default=Path(__file__).with_name('packing.cert.json'));args=p.parse_args()
    result=audit(args.certificate)
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
