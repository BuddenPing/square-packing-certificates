"""Exact lossless reconstruction of N261's declared physical support word."""
from fractions import Fraction as Q
import json,gzip,hashlib
from exact_sat import basis,dot,vertices

def verify_support_word(source,new,root):
 packed=json.loads(gzip.decompress((root/'construction/support-word-marks.json.gz').read_bytes()))
 header=packed['header'];marks=packed['marks'];n=source['n'];L=Q(source['s_exact']);N=Q(new['s_exact'])
 assert n==new['n']==261 and len(marks)==4*n+n*(n-1)//2
 assert header['source_sha256']==hashlib.sha256((root/'construction/centre-input.cert.json').read_bytes()).hexdigest()
 assert Q(header['source_side'])==L
 meta=json.loads((root/'construction/centre-map.json').read_text());assert meta['source_sha256']==header['source_sha256']
 limit=Q(meta['componentwise_pre_repair_limit']);assert limit==Q(header['displacement_limit'])==Q(1,10**6)
 shifts=list(map(Q,meta['rational_increments']));assert len(shifts)==2*n+1 and max(map(abs,shifts))<=limit
 S=[tuple(map(Q,r))for r in source['squares']];T=[tuple(map(Q,r))for r in new['squares']];B=[basis(r[2])for r in S]
 assert [s[2]for s in S]==[s[2]for s in T]
 raw=[(x+shifts[2*i],y+shifts[2*i+1],t)for i,(x,y,t)in enumerate(S)];rawside=L+shifts[-1]
 q=Q(meta['common_dilation']);qmin=Q(1);finalshifts=[z for a,b in zip(S,T)for z in(b[0]-a[0],b[1]-a[1])]+[N-L]
 h=hashlib.sha256();prefix=json.dumps(header,separators=(',',':'));h.update((prefix[:-1]+',"rows":[').encode());index=0;omitted=0
 def row(coeff,gap,mark):
  nonlocal index,omitted
  assert marks[index]==mark
  assert gap>=0
  assert sum(v*finalshifts[k]for k,v in coeff.items())<=gap
  if gap>limit*sum(map(abs,coeff.values())):omitted+=1
  value={'mark':mark,'coefficients':[[i,str(v)]for i,v in coeff.items()],'gap':str(gap)}
  if index:h.update(b',')
  h.update(json.dumps(value,separators=(',',':')).encode());index+=1
 for i,(x,y,t)in enumerate(S):
  support=sum(map(abs,B[i][0]))/2
  row({2*i:-1},x-support,['left',i]);row({2*i:1,2*n:-1},L-x-support,['right',i])
  row({2*i+1:-1},y-support,['bottom',i]);row({2*i+1:1,2*n:-1},L-y-support,['top',i])
  for d in[raw[i][0],raw[i][1],rawside-raw[i][0],rawside-raw[i][1]]:
   assert d>0;qmin=max(qmin,support/d)
  for j in range(i):
   delta=(x-S[j][0],y-S[j][1]);rawdelta=(raw[i][0]-raw[j][0],raw[i][1]-raw[j][1]);options=[];needs=[]
   for k,axis in enumerate((*B[i],*B[j])):
    dd=dot(axis,delta);r=sum(abs(dot(v,axis))for v in(*B[i],*B[j]))/2
    options.append((abs(dd)/r,k,axis,dd,r));rd=abs(dot(axis,rawdelta))
    if rd:needs.append(r/rd)
   assert needs;qmin=max(qmin,min(needs))
   _,k,axis,dd,r=max(options,key=lambda z:z[0]);sign=1 if dd>=0 else -1;ax,ay=sign*axis[0],sign*axis[1]
   row({2*i:-ax,2*i+1:-ay,2*j:ax,2*j+1:ay},abs(dd)-r,['pair',j,i,k,sign])
 h.update(b']}\n');assert index==len(marks)and h.hexdigest()==packed['original_word_sha256']
 assert q==qmin
 scaled=[(q*x,q*y,t)for x,y,t in raw];V=[v for r in scaled for v in vertices(*r)]
 x0=min(x for x,y in V);y0=min(y for x,y in V);assert [x0,y0]==list(map(Q,meta['crop_origin']))
 reconstructed=[(x-x0,y-y0,t)for x,y,t in scaled];assert reconstructed==T
 side=max(max(x for x,y in V)-x0,max(y for x,y in V)-y0);assert side==N==Q(meta['new_side_exact'])
 return {'valid':True,'word_rows':index,'full_original_word_sha256':h.hexdigest(),'all_final_support_rows_satisfied':True,'exactly_box_redundant_rows':omitted,'retained_numerical_rows':index-omitted,'pre_repair_componentwise_limit':str(limit),'unchanged_owner_frames':True,'minimum_common_repair_recomputed':True,'complete_coordinate_and_box_replay':True,'final_max_componentwise_center_displacement_exact':str(max(map(abs,finalshifts[:-1])))}
