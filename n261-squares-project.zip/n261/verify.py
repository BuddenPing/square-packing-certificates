"""Portable exact-rational certificate and construction verifier (Python 3.10+).
No network, numerical tolerance, optimization library, or producer import.
"""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

COUNT = 261
HERE = Path(__file__).resolve().parent

def require(condition, message):
    if not condition:
        raise ValueError(message)

def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f'Duplicate JSON key: {key}')
        result[key] = value
    return result

def load(name):
    return json.loads((HERE / name).read_text(), object_pairs_hook=unique_object)

def digest(name):
    return hashlib.sha256((HERE / name).read_bytes()).hexdigest()

def vertices(row):
    x, y, t = map(F, row)
    d = 1+t*t
    c, s = (1-t*t)/d, 2*t/d
    return [(x+(a*c-b*s)/2, y+(a*s+b*c)/2)
            for a, b in ((-1,-1), (1,-1), (1,1), (-1,1))]

def check(cert):
    n = cert['n']
    require(type(n) is int and n == COUNT and len(cert['squares']) == n, 'Incorrect square count')
    side = F(cert['s_exact'])
    require(side > 0, 'Nonpositive side')
    vv = [vertices(row) for row in cert['squares']]
    axes, boxes = [], []
    for i, v in enumerate(vv):
        require(all(0 <= x <= side and 0 <= y <= side for x, y in v), f'Square {i}: wall violation')
        e = [(v[(j+1)%4][0]-v[j][0], v[(j+1)%4][1]-v[j][1]) for j in range(4)]
        require(all(x*x+y*y == 1 for x, y in e), f'Square {i}: nonunit edge')
        require(all(e[j][0]*e[(j+1)%4][0]+e[j][1]*e[(j+1)%4][1] == 0 for j in range(4)), f'Square {i}: nonperpendicular edges')
        require(sum(v[j][0]*v[(j+1)%4][1]-v[j][1]*v[(j+1)%4][0] for j in range(4)) == 2, f'Square {i}: area or orientation')
        axes.append(e[:2])
        boxes.append((min(x for x,y in v), max(x for x,y in v), min(y for x,y in v), max(y for x,y in v)))
    pairs = 0
    for i in range(n):
        for j in range(i):
            pairs += 1
            a, b = boxes[i], boxes[j]
            if a[1] <= b[0] or b[1] <= a[0] or a[3] <= b[2] or b[3] <= a[2]:
                continue
            separated = False
            for ax, ay in axes[i]+axes[j]:
                a = [ax*x+ay*y for x,y in vv[i]]
                b = [ax*x+ay*y for x,y in vv[j]]
                if max(a) <= min(b) or max(b) <= min(a):
                    separated = True
                    break
            require(separated, f'Interior overlap: {j}, {i}')
    return vv, pairs

def main():
    n = COUNT
    prior = load(f'n{n}-prior.cert.json')
    new = load(f'n{n}.cert.json')
    receipt = load(f'n{n}-construction-receipt.json')
    provenance = load('PROVENANCE.json')
    require(digest(f'n{n}.cert.json') == provenance['candidate_sha256'] == receipt['candidate_sha256'], 'Candidate hash mismatch')
    require(digest(f'n{n}-prior.cert.json') == provenance['prior_normalized_certificate_sha256'] == receipt['source_sha256'], 'Prior hash mismatch')
    raw_source_name = provenance['original_source_file']
    require(digest(raw_source_name) == provenance['original_source_sha256'], 'Original public source hash mismatch')
    rows = [line.split() for line in (HERE / raw_source_name).read_text().splitlines()
            if line.strip() and not line.lstrip().startswith('#')]
    require(int(rows[0][0]) == n and F(rows[0][1]) == F(prior['s_exact']), 'Original public source header mismatch')
    require([tuple(map(F,row)) for row in rows[1:]] == [tuple(map(F,row)) for row in prior['squares']], 'Original public source geometry mismatch')
    oldside, side = F(prior['s_exact']), F(new['s_exact'])
    require(0 < side < oldside, 'Not a strict upper-bound improvement')
    require(side == F(receipt['new_side']) and oldside == F(receipt['old_side']), 'Side receipt mismatch')
    require(oldside-side == F(receipt['gain']), 'Improvement receipt mismatch')
    q = F(receipt['q'])
    tx, ty = map(F, receipt['translation'])
    require(0 < q <= 1, 'Invalid contraction')
    require(len(prior['squares']) == len(new['squares']) == n, 'Count mismatch')
    for p, z in zip(prior['squares'], new['squares']):
        x, y, t = map(F, p)
        require(tuple(map(F, z)) == (q*x+tx, q*y+ty, t), 'Exact construction replay failed')
    check(prior)
    vv, pairs = check(new)
    require(min(x for v in vv for x,y in v) == min(y for v in vv for x,y in v) == 0, 'Enclosure origin not tight')
    require(max(max(x for v in vv for x,y in v), max(y for v in vv for x,y in v)) == side, 'Enclosure side not tight')
    document = load(f'pingyou-n{n}-rational.yaml')
    require(document['softschema']['contract'] == 'packing.squares:Witness/v2', 'Wrong native schema')
    w = document['witness']
    require(w['n'] == n and F(w['side']) == side and F(w['square_size']) == 1, 'Native count/side/size mismatch')
    require(w['representation'] == 'corners' and w['scalar'] == {'kind':'rational'}, 'Wrong native representation')
    require(w['coordinates'] == {'origin':'lower-left','axes':'x-right-y-up','angle_unit':'not-applicable'}, 'Wrong native coordinate frame')
    require(len(w['squares']) == n, 'Native count mismatch')
    for index, (points, sq) in enumerate(zip(vv, w['squares']), 1):
        require(sq['id'] == index and [tuple(map(F,p)) for p in sq['corners']] == points, 'Native exact conversion mismatch')
    print(json.dumps({
        'valid': True, 'n': n, 'candidate_sha256': digest(f'n{n}.cert.json'),
        'prior_sha256': digest(f'n{n}-prior.cert.json'),
        'native_witness_sha256': digest(f'pingyou-n{n}-rational.yaml'),
        'side_exact': str(side), 'improvement_exact': str(oldside-side),
        'construction_replay': True, 'prior_feasibility': True,
        'unit_shapes': n, 'walls_checked': 4*n, 'pairs_checked': pairs,
        'native_conversion_identity': True,
        'arithmetic': 'Exact fractions; zero boundary clearance is allowed.'
    }, indent=2))

if __name__ == '__main__':
    main()
