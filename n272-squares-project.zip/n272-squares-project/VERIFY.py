#!/usr/bin/env python3
"""Complete exact replay; Python standard library only, without optimization."""
from pathlib import Path
from fractions import Fraction as F
import copy,hashlib,json,subprocess,sys
from exact_sat import exact_check
from exact_polygon import audit
P=Path(__file__).resolve().parent

def require(c,m):
 if not c:raise ValueError(m)
def read(name):return json.loads((P/name).read_text())
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def text_cert(path):
 a=[l.split() for l in path.read_text().splitlines() if l.strip() and not l.startswith('#')]
 require(len(a)==int(a[0][0])+1,'Text certificate count')
 return {'n':int(a[0][0]),'s_exact':str(F(a[0][1])),'squares':[[str(F(v)) for v in r] for r in a[1:]]}
def geometry_identity(a,b):
 return a['n']==b['n'] and F(a['s_exact'])==F(b['s_exact']) and [[F(z) for z in r] for r in a['squares']]==[[F(z) for z in r] for r in b['squares']]
require(__debug__,'Run without -O; the independent polygon and optional dual checkers contain assertions.')
for line in (P/'SHA256SUMS').read_text().splitlines():
 h,name=line.split('  ',1);require(digest(P/name)==h,'Hash mismatch: '+name)
new=read('n272.cert.json');old=read('n272-prior.cert.json');projection=read('n272-source-projection.cert.json')
reports={}
for label,obj in [('new',new),('prior',old),('inherited_contact_projection',projection)]:
 require(obj['n']==272 and len(obj['squares'])==272,'Wrong physical square count')
 a=exact_check(obj);b=audit(obj)[0]
 require(a['valid'] and b['valid'] and a['pairs_checked']==36856 and b['pairs_checked']==36856,'Geometry failure: '+label)
 reports[label]={'exact_vertex_sat':a,'exact_polygon':b}
require(geometry_identity(new,text_cert(P/'construction/n272.cert')),'Final native rational text binding')
require(geometry_identity(projection,text_cert(P/'construction/source-projection.cert')),'Projection native rational text binding')
require(geometry_identity(old,read('construction/source.cert.json')),'Original physical geometry binding')
require(digest(P/'n272.cert.json')==digest(P/'construction/n272.cert.json'),'Final JSON identity')
prov=read('PROVENANCE.json');cp=read('construction/PROVENANCE.json')
require(digest(P/'n272-prior.cert.json')==prov['source_sha256']==prov['prior_sha256'],'Original pinned source bytes')
require(digest(P/'n272.cert.json')==prov['candidate_sha256'],'Final candidate bytes')
for name,h in cp['files'].items():require(digest(P/'construction'/name)==h,'Construction source binding: '+name)
for name,row in read('source-manifest.json').items():
 require(digest(P/row['path'])==row['sha256'],'Original solver source binding: '+name)
 require('/'+prov['solver_commit']+'/' in row['url'],'Unpinned solver source')
cmp=read('COMPARISON.json');a,b,c=F(new['s_exact']),F(old['s_exact']),F(projection['s_exact'])
require(a<c<b,'Not a strict improvement over prior and inherited projection')
require(F(cmp['candidate_side'])==a and F(cmp['prior_certificate_side'])==b and F(cmp['inherited_contact_projection_side'])==c,'Comparison geometry binding')
require(F(cmp['improvement_over_prior'])==b-a and F(cmp['improvement_over_inherited_projection'])==c-a,'Exact comparison arithmetic')
require(F(prov['new_side_exact'])==a and F(prov['published_side_exact'])==b and F(prov['pre_KKT_projection_side_exact'])==c,'Provenance side binding')
public=read('evidence/public-comparison.json')
require(F(public['candidate_side_exact'])==a and public['candidate_sha256']==digest(P/'n272.cert.json'),'Public comparison candidate binding')
require(all(F(row['side_exact'])>a and row['strictly_above_candidate'] for row in public['public_bounds']),'Public bound comparison')
aux=read('evidence/n272-auxiliary-source-comparison.json')
require(F(aux['candidate_side_exact'])==a and a<F(aux['source_side_exact']),'Auxiliary public source comparison')
contacts=read('construction/final.contacts.json');initial=read('construction/source-projection.contacts.json');lower=read('construction/final100.contacts.json')
require(contacts['equations']==initial['equations']==lower['equations'] and len(contacts['equations'])==1564,'Contact equation identity')
require(set(contacts['frozen_vars'])==set(initial['frozen_vars'])==set(lower['frozen_vars']),'Frozen coordinate identity')
require(len(contacts['frozen_vars'])==22 and all(v%3 in [0,1] for v in contacts['frozen_vars']),'Frozen variables must be 22 translations')
require(set(contacts['free'])=={115,116},'Expected free physical squares')
require(all(abs(F(new['squares'][i][2])-F(old['squares'][i][2]))<F(1,10**105) for i in contacts['free']),'Inherited free orientations beyond rationalization precision')
require(abs(F(contacts['S'])-F(lower['S']))<F(1,10**88),'Precision consistency')
sys.path.insert(0,str(P/'native'));from convert_witness import check_identity
reports['native_roundtrip']=check_identity(new,read('pingyou-n272-rational.yaml'))
check=subprocess.run([sys.executable,'-B',str(P/'construction/verify_original_angle_bound.py')],capture_output=True,text=True,check=True)
reports['optional_original_angle_dual']={'valid':True,'scope':'Selected source SAT separation branches with each original orientation within1e-25radians of its published value. This is not a guarantee about the original unpublished generator.','checker_output':check.stdout.strip()}
for kind in ['duplicate','outside']:
 bad=copy.deepcopy(new)
 if kind=='duplicate':bad['squares'][1]=bad['squares'][0][:]
 else:bad['squares'][0][0]='-2'
 require(not exact_check(bad)['valid'],kind+' negative control accepted by SAT')
 try:audit(bad)
 except AssertionError:pass
 else:raise ValueError(kind+' negative control accepted by polygon checker')
reports['negative_controls']='Both exact checkers reject duplicate and outside squares'
reports['source_and_contact_bindings_verified']=True
reports['all_valid']=True
print(json.dumps(reports,indent=2))
