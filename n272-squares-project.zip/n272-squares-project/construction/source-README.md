# SQUISH: 9 new packings, four of them smaller packings of counts already ours (2026-10-11)

Packings of n unit squares in a square of smaller side than the best known, as listed on the Squares
Project's known-best table (https://jlevy.github.io/squares/), read 2026-10-11. Counts: 176, 181, 238, 239, 270, 271, 272, 304, 305. Four of them replace
packings we filed earlier: 238 and 239 (jlevy/squares#401) and 270 and 305 (jlevy/squares#481).

| n | our side | known best | improvement | type vs the record |
|---|---|---|---|---|
| 176 | 13.812856253277056 | 13.822875655532 | 1.002e-02 | new alignment |
| 181 | 13.950819531022924 | 13.953748821954 | 2.929e-03 | new alignment |
| 238 | 15.924106785321494 | 15.926146857011 | 2.040e-03 | rearrangement |
| 239 | 15.948443327300499 | 15.949313169728 | 8.698e-04 | rearrangement |
| 270 | 16.928196993329016 | 16.937807228446 | 9.610e-03 | new geometry |
| 271 | 16.949116687815009 | 16.950820792625 | 1.704e-03 | new alignment |
| 272 | 16.965586474837671 | 16.968110145770 | 2.524e-03 | rearrangement |
| 304 | 17.929657042170880 | 17.934650018391 | 4.993e-03 | new alignment |
| 305 | 17.950544853925636 | 17.952959459016 | 2.415e-03 | rearrangement |

Sides to 40 digits, exact fractions, the sources of the known bests and the pieces each packing uses: `summary.csv`.
`sources/`: certificates of five of our earlier, unfiled packings (two of n = 154, and n = 240, 272 and 305) that pieces
were taken from. A sixth, of n = 240, is in the 2026-10-09 package's `sources/` (`squish-s240-source`).

## Contents
Each `nNNN/` folder holds:
* `nNNN.cert.json`: the exact certificate. Every square's centre (x, y) is a rational and its angle is given by
  the rational t = tan(theta/2), so cos = (1-t^2)/(1+t^2) and sin = 2t/(1+t^2) exactly and every square is
  exactly a unit square; the box is [0, S]^2 with S the exact fraction `s_exact`;
* `nNNN.cert.txt`: the same packing in Ellsworth's text format at 50 digits (box centred at the origin), the input
  of his check_packing.py;
* `nNNN.svg`, `nNNN.cert50.txt`: a drawing made from the certificate at 50 digits;
* `nNNN_vs_record.png`: the record packing this was compared with and this packing, to one scale;
* `check_packing_output.txt`: check_packing.py's output on `nNNN.cert.txt`.

## Verification
1. **Exact rational check** (SQUISH): every pair of squares close enough to touch is tested with the
   separating-axis theorem in exact rational arithmetic, and every square against the box; S is the exact
   extent. All pass, in seconds each.
2. **David Ellsworth's check_packing.py** on `nNNN.cert.txt`: `Epsilon: 1E-50 · Container: OK · Overlaps: NONE ·
   VALID` for all. Rerun: `python check_packing.py nNNN/nNNN.cert.txt` (under a second each).
The two share only the certificate data (the 50-digit file rounds the exact one outward); they are separate code
by separate authors. The `sources/` certificates pass both checks too.

## Mondrian
All 9 were found by Mondrian, SQUISH's composition method: known packings are cut into rectangular pieces
(sub-packings), two pieces are placed in opposite corners of a box with whole rows and columns of unit squares
filling the rest, and a search that repairs the composed layout's seams brings it below the record. New since
2026-10-09: pieces narrowed in their own rectangle before composing (all but 176), and interlocked pieces (176:
a 2 x 3 block of cells cut from a corner of Couzo's s(127), with s(5) reaching into it).

## Pieces
Each packing uses pieces of the packings named in `summary.csv` (`found_by`), with the number of squares taken from
each and where to find that packing, followed by the steps run after composition. The pieces come from Francisco
Couzo's s(127) (jlevy/squares#451); the Kingbird catalogue's s(5) and its former records for n = 11, 19 and 182;
our s(209) (#401, as refined by Siddharth Gupta on the register, and #481); and our unfiled packings of n = 154,
240, 272 and 305 (see `sources/`).

## Finishing
Before certification, each packing's contact equations (corner on edge, corner on wall) were solved at 60 digits,
and the rational certificate drawn from that solution with a clearance of 1e-32. So each S is within about 1e-30
of the bottom of its arrangement. Each was then given an hour of nearby search and a deep squeeze; the squeeze
moved none of them by more than 7e-07.

## Not done
Upper bounds only: no optimality claim, no analytic (minimal-polynomial) form of the sides, no formal proof. The
checks above were run by us.
