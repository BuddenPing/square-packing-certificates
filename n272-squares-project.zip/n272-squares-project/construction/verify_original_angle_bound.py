#!/usr/bin/env python3
"""Exact rational dual check; standard library only. Scope is stated in the JSON."""
from pathlib import Path
from fractions import Fraction as F
import json
D=Path(__file__).resolve().parent
src=json.loads((D/'source.cert.json').read_text());proof=json.loads((D/'original-angle-lower-bound.json').read_text());new=json.loads((D/'n272.cert.json').read_text())
assert __debug__, 'Run without -O'
assert src['n']==new['n']==proof['n']==272
assert len(src['squares'])==len(new['squares'])==272
assert F(new['s_exact'])==F(proof['new_candidate_exact'])
n=src['n'];sq=[[F(z) for z in row] for row in src['squares']];m=2*n+1
axes=[];hs=[]
for x,y,t in sq:
 c=(1-t*t)/(1+t*t);s=2*t/(1+t*t);axes.append([(c,s),(-s,c)]);hs.append((abs(c)+abs(s))/2)
res=[F(int(k==m-1)) for k in range(m)];objective=F(0);weight_sum=F(0)
for row in proof['dual_constraints']:
 label=row['label'];a={int(k):F(v) for k,v in row['terms'].items()};w=F(row['weight']);assert w<=0
 if label[0]=='wall':
  _,i,wall=label
  expected={'left':{2*i:F(-1)},'bottom':{2*i+1:F(-1)},'right':{2*i:F(1),m-1:F(-1)},'top':{2*i+1:F(1),m-1:F(-1)}}[wall]
  assert a==expected;b=-hs[i]
 else:
  _,i,j=label;u,v=-a[2*i],-a[2*i+1]
  assert a=={2*i:-u,2*i+1:-v,2*j:u,2*j+1:v}
  aa=axes[i]+axes[j];assert (u,v) in aa+[(-c,-s) for c,s in aa]
  b=-sum(abs(u*c+v*s) for c,s in aa)/2
 Z=[F(v) for rr in src['squares'] for v in rr[:2]]+[F(src['s_exact'])]
 assert sum(z*Z[k] for k,z in a.items())<=b, 'Selected branch fails in source'
 for k,z in a.items():res[k]-=w*z
 objective+=w*b;weight_sum+=abs(w)
lower=objective+17*sum(min(z,0) for z in res)
assert lower==F(proof['lower_bound_exact']) and lower<17
# On [0,17]^2, changing each orientation by <=d changes every selected
# pair or wall inequality by at most100*d (a conservative Lipschitz bound).
# In detail: 17*sqrt(2)*d for the center-axis term plus4*d for the
# half-sum of four support dot products is <29*d; wall change <=d.
d=F(proof['angular_neighborhood_radians']);assert d>0
robust=lower-100*d*weight_sum
assert robust==F(proof['robust_lower_bound_exact'])
assert F(new['s_exact'])<robust
print('PASS: exact rational dual lower bound and strict improvement; scope: fixed original SAT branches and stated angular neighborhood.')
