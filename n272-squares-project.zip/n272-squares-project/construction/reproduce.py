#!/usr/bin/env python3
"""Reproduce the contact-preserving N272 refinement from the bundled exact source."""
from pathlib import Path
import sys,json
import mpmath as mp
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D/'solver'))
import exactsolve as E
# Omit optional finite flat-motion probes; they establish properties not needed
# for the upper-bound claim and never alter the point being certified.
_original_second_order=E.second_order
def no_flat_probes(*args,**kwargs):
 out=_original_second_order(*args,**kwargs);out.pop('_zero_modes',None)
 out['optional_flat_motion_probes']='omitted: upper-bound verification only'
 return out
E.second_order=no_flat_probes
mp.mp.dps=115
src=json.loads((D/'source.cert.json').read_text())
def v(s):
 a,*b=s.split('/');return mp.mpf(a)/(mp.mpf(b[0]) if b else 1)
p=D/'rerun-input.txt'
with p.open('w') as f:
 f.write(f"272 {mp.nstr(v(src['s_exact']),110)}\n")
 for x,y,t in src['squares']:
  f.write(' '.join(mp.nstr(z,110) for z in (v(x),v(y),2*mp.atan(v(t))*180/mp.pi))+'\n')
E.run(str(p),dps=120,eps='1e-100',outdir=str(D/'rerun-output'),tol=1e-10)
