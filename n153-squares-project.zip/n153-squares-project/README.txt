PINGYOU LTD - 153 UNIT SQUARES

Exact side:
6435006925203522001385040447/500000000000000000000000000
= 12.870013850407044002770080894
Safe upward display: s(153) <= 12.870013850408.

Run from any directory, Python 3.10+ standard library, without -O:
    python3 /path/to/n153-squares-project/VERIFY.py

This checks file hashes, reconstructs the exact witness from the explicit
rational construction table, recomputes its guard, and runs three exact
geometric implementations on the candidate, source and comparison witnesses.
Every candidate pair is decided: 153 squares, 11,628 unordered pairs, all walls.
It also verifies lossless conversion to the native Squares Project Witness/v2.
The replay does not rerun exploratory combinatorial selection or a float solver.

Optional symbolic derivation (requires SymPy):
    python3 evidence/derive_half_return.py

The native/ folder contains the exact Witness/v2, conversion checker, pinned
upstream replay wrapper, source manifest, schema, licence and successful
Squares Project exact-check receipts. Its README documents upstream replay.

Public comparison checked 11 October 2026: prior exact side
12.872029849081179973762429831968 (SQUISH construction, Evan Daniel
regularization, Squares Project T-146). Side improvement is
0.002015998674135970992348937968, approximately 0.0156618552%.
The prior numerical report is also strictly above the new exact certificate.

Credit: PingYou Ltd for the N153 construction; Ryan Xu for the underlying N70
construction; Evan Daniel for exact source retention and prior regularization;
Nate Chaoweeraprasit (SQUISH) for the prior N153 construction.

The geometric checks prove feasibility, not local or global optimality.
All checkers consume the same exact geometry. Separating-axis implementations
share a mathematical criterion; polygon intersection supplies another check.
The retained receipts do not claim independent human review or maintainer
acceptance. Included source material retains its provenance and licence terms.
See evidence/PROVENANCE.txt for historical path labels and PDF status wording.
