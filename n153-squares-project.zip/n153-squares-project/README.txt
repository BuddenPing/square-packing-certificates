153 unit squares: refined exact feasible upper bound
Construction and refinement: PingYou Ltd

s(153) <= 3217503462601758500692520223/250000000000000000000000000
        = 12.870013850407034002770080892
        < 12.870013850408 (upward-rounded reporting bound).

With Python 3.10+ and the extracted package:
  python3 VERIFY.py
Run without -O. The default replay uses only the standard library.

This is a small refinement of the N153 construction submitted in issue 504:
https://github.com/jlevy/squares/issues/504
The previous certificate, registered as T-148, has exact side
6435006925203522001385040447/500000000000000000000000000
=12.870013850407044002770080894.
The exact reduction is 0.000000000000010000000000002. The twelve-decimal
upward reporting bound remains unchanged. See evidence/comparison.json.

The refinement realizes the same selected physical-owner word at the same
derived A=C frame. Its rational orientations and guard multiplier
5000000000001/5000000000000 are unchanged. Some free centers change; the
largest rowwise coordinate change is approximately 0.06969382697643393.
It is a different finite realization of the existing construction, not a
new contact-return equation or merely a different printed decimal.

The complete certificate has 153 unit squares, 612 wall conditions and 11628
unordered pairs. All walls and pairs have strictly positive clearance.
Minimum wall clearance is 1e-13; minimum unit-axis separating gap is about
1.879768296010611e-13. Three exact geometric implementations accept it:
an exhaustive rational vertex-projection checker and Evan Daniel's unchanged
exact separating-axis and polygon-intersection checkers. The previous
certificate, selected parent and N70 source are also checked. Duplicate-square
and outside-wall negative controls must be rejected.

construction/reproduce.py decodes every retained parent owner from the N70
source or the two upright registers, verifies the inherited A=C root interval,
reconstructs the new exact table, and recomputes its complete all-pair guard.
It reproduces every exact final coordinate. It does not rerun exploratory
owner selection or a floating point linear solve. The optional symbolic
return check requires SymPy:
  python3 construction/derive_half_return.py

The native/ folder contains the exact Squares Project Witness/v2 and its
lossless conversion check. See its README for the additional pinned upstream
native checks and dependencies. Native geometry is identical to this package's
rational certificate. The PDF and SVG are illustrations, not the witness.

Credit and lineage
PingYou Ltd: N153 construction and this finite refinement.
Ryan Xu: underlying N70 construction, announced in issue 432.
Evan Daniel: retained exact N70 source, prior regularization and exact checkers.
Nate Chaoweeraprasit (SQUISH): the prior N153 construction before this family.
Joshua Levy and the Squares Project: native format and upstream checking tools.
Source links, hashes and applicable licenses accompany the relevant files.
No new license grant is inferred for unrelated third-party material.

These are feasibility checks, not proofs of local or global optimality, and
they do not imply independent human review or maintainer acceptance. The
portable certificate removes only internal nongeometric metadata; exact
strings, owner order, count and side are preserved. evidence/source-binding.json
binds it to the reviewed original certificate.
