#!/usr/bin/env python3
"""Verify the refined N153 release using the Python standard library."""
from pathlib import Path
from fractions import Fraction as F
import argparse, hashlib, json, subprocess, sys, tempfile

ROOT=Path(__file__).resolve().parent

def run(script,*args,ok=True):
    p=subprocess.run([sys.executable,'-B',str(ROOT/script),*[str(a) for a in args]],
                     capture_output=True,text=True)
    if (p.returncode==0)!=ok:
        raise RuntimeError(str(script)+'\n'+p.stdout+p.stderr)
    return p.stdout

def native(obj):
    return str(obj['n'])+' '+obj['s_exact']+'\n'+'\n'.join(' '.join(row) for row in obj['squares'])+'\n'

def main():
    if not __debug__:raise RuntimeError('Run without -O; active assertions are required')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--core-only',action='store_true',help='Packaging check before native files and final hashes are added')
    parser.add_argument('--receipt',type=Path)
    args=parser.parse_args()
    if not args.core_only:
        for line in (ROOT/'SHA256SUMS').read_text().splitlines():
            expected,name=line.split('  ',1)
            if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=expected:
                raise ValueError('Hash mismatch: '+name)
    cert=ROOT/'evidence/packing.cert.json';obj=json.loads(cert.read_text())
    oldpath=ROOT/'construction/previous-n153.cert.json';old=json.loads(oldpath.read_text())
    comparison=json.loads((ROOT/'evidence/comparison.json').read_text())
    assert F(comparison['previous']['side_exact'])==F(old['s_exact'])
    assert F(comparison['refined']['side_exact'])==F(obj['s_exact'])
    assert F(old['s_exact'])-F(obj['s_exact'])==F(comparison['improvement_exact'])>0
    binding=json.loads((ROOT/'evidence/source-binding.json').read_text())
    assert hashlib.sha256(cert.read_bytes()).hexdigest()==binding['portable_certificate_sha256']
    geometry=json.loads(run('checkers/verify_n153.py',cert))
    assert geometry['valid'] and geometry['pairs_checked']==11628 and geometry['wall_constraints_checked']==612
    assert geometry['unique_physical_squares']==153 and geometry['all_pairs_have_strict_separating_gap']
    run('checkers/verify_n153.py',oldpath)
    run('checkers/verify_n153.py',ROOT/'construction/selected-parent.cert.json')
    replay=json.loads(run('construction/reproduce.py','--certificate',cert))
    if not args.core_only:
        run('native/convert_witness.py',cert,ROOT/'native/pingyou-n153-rational.yaml','--check')
    assert (ROOT/'evidence/n153.cert').read_text()==native(obj)
    assert (ROOT/'evidence/previous-n153.cert').read_text()==native(old)
    with tempfile.TemporaryDirectory() as folder:
        folder=Path(folder)
        for name,path in [('refined',cert),('previous',oldpath),
                          ('selected-parent',ROOT/'construction/selected-parent.cert.json'),
                          ('source-n070',ROOT/'construction/source-n070.cert.json')]:
            text=folder/(name+'.cert');text.write_text(native(json.loads(path.read_text())))
            for check in ['verify_cert.py','verify_cert2.py']:
                run('checkers/'+check,text)
        for name in ['duplicate-square','outside-wall']:
            bad=json.loads(cert.read_text())
            if name=='duplicate-square':bad['squares'][1]=bad['squares'][0][:]
            else:bad['squares'][0][0]='-1'
            jp=folder/(name+'.json');jp.write_text(json.dumps(bad))
            cp=folder/(name+'.cert');cp.write_text(native(bad))
            run('checkers/verify_n153.py',jp,ok=False)
            for check in ['verify_cert.py','verify_cert2.py']:
                run('checkers/'+check,cp,ok=False)
    report={'valid':True,'core_only':args.core_only,'n':153,'wall_constraints':612,
            'unordered_pairs':11628,'three_exact_geometry_checks':True,
            'previous_and_selected_parent_verified':True,'n070_source_verified':True,
            'exact_owner_decoder_and_construction_replay':True,
            'unchanged_guard_verified':replay['guard_unchanged_from_previous_release'],
            'side_exact':obj['s_exact'],'improvement_exact':comparison['improvement_exact'],
            'duplicate_and_outside_wall_controls_rejected_by_all_three':True,
            'native_conversion_checked':not args.core_only,'file_hashes_checked':not args.core_only,
            'minimum_wall_clearance_exact':geometry['minimum_wall_clearance_exact'],
            'minimum_best_unit_axis_pair_gap_exact':geometry['minimum_best_unit_axis_pair_gap_exact']}
    if args.receipt:args.receipt.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
