"""Verify the complete N153 submission using Python's standard library."""
from pathlib import Path
from fractions import Fraction as F
import hashlib, json, subprocess, sys, tempfile, shutil
ROOT=Path(__file__).resolve().parent
if not __debug__:
    raise SystemExit('Run without -O; assertions are required.')
manifest=json.loads((ROOT/'manifest.json').read_text())
for name, expected in manifest['sha256'].items():
    p=ROOT/name
    assert p.is_file(), 'Missing file: '+name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==expected, 'Hash mismatch: '+name
cert=json.loads((ROOT/'evidence/packing.cert.json').read_text())
binding=json.loads((ROOT/'evidence/document-binding.json').read_text())
assert hashlib.sha256((ROOT/'evidence/packing.cert.json').read_bytes()).hexdigest()==binding['published_certificate_sha256']
geom=json.dumps({k:cert[k] for k in ['n','s_exact','squares']},sort_keys=True,separators=(',',':')).encode()
assert hashlib.sha256(geom).hexdigest()==binding['canonical_geometry_sha256']
assert cert['n']==len(cert['squares'])==153
assert F(cert['s_exact'])==F('6435006925203522001385040447/500000000000000000000000000')
# The standalone evidence replay writes a receipt. Use a temporary copy so
# verification preserves the published files and their checksums.
with tempfile.TemporaryDirectory(prefix='n153-replay-') as td:
    copy=Path(td)/'evidence'; shutil.copytree(ROOT/'evidence', copy)
    proc=subprocess.run([sys.executable,'-B',str(copy/'reproduce.py')],capture_output=True,text=True,check=True)
    result=json.loads(proc.stdout)
    assert result['valid'] and result['certificates_checked']==5
    audit=json.loads((copy/'reproduction_audit.json').read_text())
    assert audit['construction_table_identity'] and audit['guard_recomputed_exactly']
    assert (copy/'reproduction_audit.json').read_bytes()==(ROOT/'evidence/reproduction_audit.json').read_bytes()
proc=subprocess.run([sys.executable,'-B',str(ROOT/'native/convert_witness.py'),str(ROOT/'evidence/packing.cert.json'),str(ROOT/'native/pingyou-n153-rational.yaml'),'--check'],capture_output=True,text=True,check=True)
assert json.loads(proc.stdout)['valid']
print(json.dumps({'valid':True,'n':153,'pairs':11628,'manifest_files':len(manifest['sha256']), 'reconstructed_exactly':True,'guard_recomputed':True,'three_exact_geometry_checks':True,'native_conversion_identity':True},indent=2))
