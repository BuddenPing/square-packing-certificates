#!/usr/bin/env python3
"""Replay the pinned Squares Project verifiers without modifying upstream code.

Use Python 3.14 and the pinned checkout's dependencies, then run from package root:
  python3 native/replay_upstream.py --checkout /path/to/squares \
      --witness native/pingyou-nNNN-rational.yaml

The witness count and all expected pair counts are obtained from the witness.
The retained source manifest is checked before importing upstream modules.
"""
import argparse
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import platform
import sys
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkout', type=Path, required=True)
    parser.add_argument('--witness', type=Path, required=True)
    parser.add_argument('--source-manifest', type=Path,
                        default=Path(__file__).with_name('upstream-source-manifest.json'))
    args = parser.parse_args()
    manifest = json.loads(args.source_manifest.read_text())
    checkout = args.checkout.resolve()
    for entry in manifest['files']:
        actual = hashlib.sha256((checkout/entry['path']).read_bytes()).hexdigest()
        if actual != entry['sha256']:
            raise ValueError(f"Pinned upstream source mismatch: {entry['path']}")
    schema_entry = next(e for e in manifest['files'] if e['path'].endswith('/witness.schema.yaml'))
    if hashlib.sha256(args.witness.with_name('witness.schema.yaml').read_bytes()).hexdigest() != schema_entry['sha256']:
        raise ValueError('Witness schema differs from pinned upstream schema')
    sys.path.insert(0, str(checkout/'packing'))
    sys.path.insert(0, str(checkout/'packing/src'))
    from sqpack.witness import load_witness, exact_verify
    from devtools.check_rational_witness_independent import check

    started = time.perf_counter()
    witness = load_witness(args.witness)
    result, report = exact_verify(witness)
    native_seconds = time.perf_counter()-started
    started = time.perf_counter()
    independent = check(args.witness)
    independent_seconds = time.perf_counter()-started
    n = witness['n']
    expected_pairs = n*(n-1)//2
    for item in (result, independent):
        if item['n'] != n or item['pairs_tested'] != expected_pairs:
            raise ValueError('Verifier did not check the complete square list and pair set')
    same_results = all(result[k] == independent[k] for k in (
        'n', 'side', 'pairs_tested', 'minimum_containment_clearance',
        'minimum_best_pair_gap', 'failures', 'verification_passed'))
    valid = report.valid and independent['verification_passed'] and same_results
    output = {
        'valid': valid,
        'source_repository': manifest['repository'],
        'source_commit': manifest['commit'],
        'upstream_source_hashes_verified': True,
        'upstream_source_manifest_sha256': hashlib.sha256(args.source_manifest.read_bytes()).hexdigest(),
        'python': platform.python_version(),
        'dependency_versions': {name: version(name) for name in ('mpmath', 'PyYAML', 'jsonschema', 'strif')},
        'witness_sha256': hashlib.sha256(args.witness.read_bytes()).hexdigest(),
        'entrypoint': 'sqpack.witness.load_witness followed by sqpack.witness.exact_verify (same functions as packing-witness verify)',
        'native_replay': result,
        'upstream_independent_checker': independent,
        'exact_result_agreement': same_results,
        'native_elapsed_seconds': native_seconds,
        'independent_elapsed_seconds': independent_seconds,
    }
    print(json.dumps(output, indent=2))
    return 0 if valid else 1


if __name__ == '__main__':
    sys.exit(main())
