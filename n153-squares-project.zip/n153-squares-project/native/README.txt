N153 rational Witness/v2 and Squares Project replay
==================================================

Claim and exact encoding
------------------------
153 unit squares fit in a square of side
6435006925203522001385040447 / 500000000000000000000000000
= 12.870013850407044002770080894.
The safe upward rounding to 12 decimal places is 12.870013850408.
This is a feasible upper bound, with no claim of global or local optimality.

pingyou-n153-rational.yaml uses JSON syntax (valid YAML), rational corner
strings, lower-left origin, x-right/y-up coordinates, and one-based square IDs
in the original order. No translation, dilation, rotation, rounding, or change
of square order is applied during conversion. The source is the exact
certificate at ../evidence/packing.cert.json.

For each source row [x,y,t], let c=(1-t*t)/(1+t*t), s=2*t/(1+t*t).
The four counterclockwise corners are
(x+(a*c-b*s)/2, y+(a*s+b*c)/2), for
(a,b)=(-1,-1),(1,-1),(1,1),(-1,1).
Every operation uses fractions.Fraction. The conversion check recovers the
center as the four-corner mean and t as s/(1+c), and compares them exactly
with every source row. It separately checks unit-square shape and containment.
The two upstream replay checkers test every pair.

Credit
------
Construction: PingYou Ltd.
Underlying N70 contact skeleton: Ryan Xu.
Retained source certificate custody: Evan Daniel.
Prior public N153 construction: Nate Chaoweeraprasit / SQUISH.

Checks supplied
---------------
conversion-check.json: exact source-to-witness round-trip for all 153 squares.
native-replay.json: both upstream verifiers accept all 153 squares and 11,628
pairs, with no failures and identical exact margins. Minimum wall clearance:
1/10000000000000. Minimum best pair gap:
33179597140421157926909562845849204519671 /
175941977475349355327789470765625000000000000000000000.

Both upstream checkers were used unchanged from jlevy/squares commit
5b0eb012e09b48b5044aacb439b4cfacf38935f5. All eleven source/schema/license
files listed in upstream-source-manifest.json were freshly compared with the
immutable raw GitHub sources before replay. replay_upstream.py rechecks the
listed local file hashes before importing upstream modules, checks the native
schema hash, and requires the complete pair count and agreement of the results.
This is a replay of the native verifier entry functions and independent checker;
it is not a full upstream repository test run or maintainer endorsement.

Reproduce from submission package root
-------------------------------------
Standard-library conversion identity check:

python3 -B native/convert_witness.py evidence/packing.cert.json native/pingyou-n153-rational.yaml --check

To generate a new copy instead, use a new output filename and omit --check.
The converter refuses to overwrite a pre-existing output.

For upstream verification, obtain jlevy/squares at the exact commit above and
use Python 3.14 with that checkout's dependencies. The replay here used Python
3.14.2, mpmath 1.4.1, PyYAML 6.0.3, jsonschema 4.26.0, and strif 3.1.0.
These four libraries and their dependencies suffice for this entry-point replay.
Install them in an environment of your choosing, or use the full checkout's
normal frozen uv environment. Then run:

python3 -B native/replay_upstream.py --checkout /path/to/squares --witness native/pingyou-n153-rational.yaml

The equivalent official CLI command, from the full checkout's packing/
directory with its dependencies installed, is:

uv run --frozen packing-witness verify /path/to/package/native/pingyou-n153-rational.yaml --json

Schema and license
------------------
witness.schema.yaml is copied unchanged from the pinned upstream commit.
Attribution for this schema: Joshua Levy, the squares project
(https://github.com/jlevy/squares). Its license is CC BY 4.0 under the upstream
repository's licensing statement. UPSTREAM-LICENSE.txt is the complete
unchanged upstream license text. Upstream verifier code is not copied into
this package; its location and exact identity are pinned in the source manifest.
