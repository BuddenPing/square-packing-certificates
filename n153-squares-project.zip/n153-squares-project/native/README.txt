N153 refined exact rational Witness/v2

Construction credit: PingYou Ltd.
Underlying N70 contact skeleton: Ryan Xu.
Retained N70 source certificate: Evan Daniel.

This witness contains exactly 153 unit squares with rational corners at side
3217503462601758500692520223/250000000000000000000000000
= 12.870013850407034002770080892. A safe upward display is 12.870013850407035.
It is a feasible upper bound; no local or global optimality is claimed.

The portable source certificate SHA-256 is 1ca754f0238f958597ecddc645aa16f5c44c3afc9cf2614b40ce2fd1f6dea670.
The native witness SHA-256 is 7cc142202fc39acfdd01060a6f89744a3f5815d6f193f03dfdb14d8c1f5c3567.
source-binding.json also binds the reviewed snapshot and canonical geometry.
The witness's source path is ../evidence/packing.cert.json.

Exact conversion
The standard-library converter maps every [x,y,t] using
(c,s)=((1-t*t)/(1+t*t),2*t/(1+t*t)) and four signed half-edge sums.
Its --check mode recovers every centre and half-angle, checks unit edges and
containment, and preserves square order. conversion-check.json binds the
portable source bytes to this witness. It is not a pairwise feasibility check.

From a release root with native/ and evidence/:
python3 -B native/convert_witness.py evidence/packing.cert.json native/pingyou-n153-rational.yaml --check

Pinned upstream verification
The retained upstream files are unchanged from jlevy/squares commit
074ac28d4ceb9a1897303f936d794771cfc6a7bd.
upstream-source-manifest.json binds each file, including the schema and license.
The wrapper verifies those hashes before importing. Both unchanged verifier
implementations passed 153 squares and 11,628 pairs:
sqpack.witness.exact_verify and devtools.check_rational_witness_independent.
They report identical exact margins and no failures.
Minimum wall clearance: 1/10000000000000.
First route: 1.883s; second: 0.868s.
See native-replay.json for the full exact results and dependency versions.

Reproduce with Python 3.14 and the pinned dependencies:
uv run --no-project --python 3.14 --with mpmath==1.4.1 --with PyYAML==6.0.3 --with jsonschema==4.26.0 --with strif==3.1.0 python -B native/replay_upstream.py --witness native/pingyou-n153-rational.yaml

Alternatively install these dependencies into a Python 3.14 environment and
run the wrapper directly. It defaults to native/upstream, a focused source
subset. A full checkout at the pinned revision may be supplied with --checkout.
The ordinary upstream command from its packing/ directory is:
uv run --frozen packing-witness verify /path/to/native/pingyou-n153-rational.yaml --json

This replay used unchanged verifier entry points. It was not a full repository
test run or maintainer endorsement of this refinement. All checkers consume
the same rational geometry. They establish finite feasibility, not optimality.

Upstream software and schema credit: Joshua Levy, the squares project,
https://github.com/jlevy/squares. The unchanged upstream license is retained
as UPSTREAM-LICENSE.txt and upstream/LICENSE. The retained upstream files
remain subject to that license.
