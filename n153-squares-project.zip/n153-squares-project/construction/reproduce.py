#!/usr/bin/env python3
"""Rebuild the refined N153 witness from its exact recorded table; stdlib only.

This checks source-owner decoding, the inherited algebraic frame interval,
all-pair guard requirements and identity with the supplied exact certificate.
It does not rerun owner selection or a floating point linear solver.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import argparse, hashlib, json

HERE = Path(__file__).resolve().parent

def require(condition, message):
    if not condition:
        raise ValueError(message)

def read(name):
    return json.loads((HERE/name).read_text())

def rows(obj):
    return [[F(x) for x in row] for row in obj['squares']]

def canonical(obj):
    return {'n':obj['n'], 's_exact':str(F(obj['s_exact'])),
            'squares':[[str(F(x)) for x in row] for row in obj['squares']]}

def digest(obj):
    return hashlib.sha256(json.dumps(canonical(obj),sort_keys=True,
                                    separators=(',',':')).encode()).hexdigest()

def basis(t):
    c,s=(1-t*t)/(1+t*t),2*t/(1+t*t)
    require(c*c+s*s==1,'unit orientation identity')
    return (c,s),(-s,c)

def dot(a,b):
    return a[0]*b[0]+a[1]*b[1]

def required_guard(side, poses):
    required=F(1); axes=[basis(t) for x,y,t in poses]
    pairs=0; walls=0
    for i,(x,y,t) in enumerate(poses):
        h=(abs(axes[i][0][0])+abs(axes[i][0][1]))/2
        for distance in [x,y,side-x,side-y]:
            require(distance>0,'nonpositive unguarded wall-center distance')
            required=max(required,h/distance);walls+=1
        for j in range(i):
            delta=(x-poses[j][0],y-poses[j][1]);options=[]
            for normal in (*axes[i],*axes[j]):
                distance=abs(dot(delta,normal))
                if distance:
                    radius=sum(abs(dot(b,normal)) for b in (*axes[i],*axes[j]))/2
                    options.append(radius/distance)
            require(bool(options),'coincident centers')
            required=max(required,min(options));pairs+=1
    return required,pairs,walls

def round_grid(q, places):
    den=10**places; value=q*den+F(1,2)
    return F(value.numerator//value.denominator,den)

def reconstruct():
    recipe=read('rational_recipe.json')
    for filename,key in [('previous-n153.cert.json','previous_certificate_sha256'),
                         ('selected-parent.cert.json','parent_certificate_sha256'),
                         ('source-n070.cert.json','n070_certificate_sha256'),
                         ('selected-owner-labels.json','owner_labels_sha256')]:
        require(hashlib.sha256((HERE/filename).read_bytes()).hexdigest()==recipe[key],
                'source hash: '+filename)
    previous=read('previous-n153.cert.json');parent=read('selected-parent.cert.json')
    source=read('source-n070.cert.json');labels=read('selected-owner-labels.json')
    prior_rows=rows(previous);parent_rows=rows(parent);source_rows=rows(source)
    require(recipe['n']==previous['n']==parent['n']==labels['n']==153,'owner count')
    require(len(prior_rows)==len(parent_rows)==len(labels['labels'])==153,'row count')
    require(source['n']==len(source_rows)==70,'N70 source count')
    require(recipe['source_owner_order']==list(range(153)),'owner correspondence')

    # Decode every retained physical parent owner, not just its numerical count.
    source_side=F(source['s_exact']);f=source_side-8
    parent_guard=F(labels['parent_center_guard']);decoded=[];alias_count=0
    for i,aliases in enumerate(labels['labels']):
        require(bool(aliases),'missing owner label')
        candidates=[]
        for kind,a,b,c in aliases:
            if kind=='source':
                station,flip,index=a,b,c
                require(type(station) is int and 0<=station<=4,'source station')
                require(flip in [0,1] and 0<=index<70,'source label')
                x,y,t=source_rows[index]
                if flip:
                    co,si=basis(t)[0]
                    require(1-si!=0,'singular source-frame representation')
                    x,y,t=source_side-y,source_side-x,-co/(1-si)
                candidate=[x+station,y+station,t]
            elif kind=='grid':
                phase,x,y=a,b,c
                require(phase in [0,1] and 0<=x<12 and 0<=y<12,'upright grid label')
                candidate=[F(x)+F(1,2)+(f if phase==1 else 0),
                           F(y)+F(1,2)+(f if phase==0 else 0),F(0)]
            else:
                raise ValueError('unknown owner label')
            candidates.append(candidate);alias_count+=1
        require(all(q==candidates[0] for q in candidates),'unequal physical aliases')
        x,y,t=candidates[0];decoded.append([x*parent_guard,y*parent_guard,t])
        require(decoded[-1]==parent_rows[i],'parent owner decode at '+str(i))
    require((source_side+4)*parent_guard==F(parent['s_exact']),'parent enclosing side')
    require(len({tuple(q) for q in decoded})==153,'distinct decoded owners')

    # Exact interval arithmetic verifies the existing degree-seven root.
    require(recipe['frame_polynomial_coefficients_descending']==[1,-9,3,-1,-1,1,-3,1],
            'A=C polynomial')
    lo,hi=map(F,recipe['frame_root_interval'])
    p=lambda u:u**7-9*u**6+3*u**5-u**4-u**3+u*u-3*u+1
    require(0<lo<hi<1,'root interval')
    require(p(lo)>0>p(hi),'root endpoint signs')
    derivative_upper=7*hi**6-54*lo**5+15*hi**4-4*lo**3-3*lo**2+2*hi-3
    require(derivative_upper<0,'unique root from negative derivative on interval')
    # The coarse inherited interval straddles a reflected-frame rounding
    # boundary. Refine it by exact bisection before proving both roundings.
    for _ in range(40):
        midpoint=(lo+hi)/2
        if p(midpoint)>0:lo=midpoint
        else:hi=midpoint
    places=recipe['frame_decimal_places']
    first=round_grid(-lo,places)
    second=round_grid((lo-1)/(lo+1),places)
    require(first==round_grid(-hi,places),'first frame rounding interval')
    require(second==round_grid((hi-1)/(hi+1),places),'reflected frame rounding interval')
    expected_frames=Counter({F(0):120,F(-1):1,first:17,second:15})
    require(Counter(row[2] for row in prior_rows)==expected_frames,'prior frame populations')

    poses=[[F(v) for v in row] for row in recipe['squares_before_guard']]
    require(len(poses)==153,'complete construction table')
    require([r[2] for r in poses]==[r[2] for r in prior_rows],'unchanged rowwise frames')
    side=F(recipe['side_before_guard']);needed,pairs,walls=required_guard(side,poses)
    den=10**13
    guard=F((needed.numerator*den+needed.denominator-1)//needed.denominator+1,den)
    require(guard==F(recipe['dilation_exact'])==F(recipe['previous_guard'])==F(5000000000001,5000000000000),
            'same recomputed guard')
    require(guard>needed,'strict guard')
    final_rows=[[x*guard,y*guard,t] for x,y,t in poses]
    result={'n':153,'s_exact':str(side*guard),'squares':[[str(v) for v in row] for row in final_rows]}
    old_side=F(previous['s_exact']);require(side*guard<old_side,'strict improvement')
    require(final_rows[0][:2]==[guard/2,guard/2],'lower corner mark')
    require(final_rows[18][:2]==[side*guard-guard/2]*2,'upper corner mark')
    report={'valid':True,'n':153,'source_owner_decoder_exact':True,'decoded_source_aliases':alias_count,
            'owner_order_matches_previous_release':True,'existing_A_equals_C_root_interval_verified':True,
            'refined_root_interval':[str(lo),str(hi)],
            'same_rowwise_rational_frames':True,'orientation_populations_mod_90':[121,17,15],
            'all_pairs_used_for_exact_guard':pairs,'wall_constraints_used_for_exact_guard':walls,
            'minimum_required_guard_exact':str(needed),'chosen_guard_exact':str(guard),
            'guard_unchanged_from_previous_release':True,'side_exact':result['s_exact'],
            'improvement_over_previous_exact':str(old_side-side*guard),'geometry_sha256':digest(result),
            'maximum_rowwise_center_change_exact':str(max(abs(a[k]-b[k]) for a,b in zip(final_rows,prior_rows) for k in [0,1])),
            'scope':'Exact parent-owner decoding and recorded-table replay of a new center realization at the inherited A=C frame. Full geometry is checked separately; no optimization or optimality claim.'}
    return result,report

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--certificate',type=Path)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--receipt',type=Path)
    args=parser.parse_args();result,report=reconstruct()
    if args.certificate:
        require(canonical(json.loads(args.certificate.read_text()))==canonical(result),'supplied certificate mismatch')
        report['supplied_certificate_matches']=True
    if args.output:args.output.write_text(json.dumps(result,indent=2)+'\n')
    if args.receipt:args.receipt.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
