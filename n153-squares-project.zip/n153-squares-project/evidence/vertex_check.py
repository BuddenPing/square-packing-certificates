"""Independent exact certification of congruent-square packing witnesses.

Search inputs use center x,y and radians. Certificates use rational tan(theta/2).
No search objective or collision routine is imported by the checker.
"""
from fractions import Fraction as F
from pathlib import Path
import json, math, argparse, time

def load_pose(path):
    d=json.loads(Path(path).read_text())
    if 's_exact' in d:
        return float(F(d['s_exact'])), [[float(F(x)),float(F(y)),2*math.atan(float(F(t)))] for x,y,t in d['squares']]
    if 'poses' in d:return float(d['side']),d['poses']
    if 's' in d:
        return float(d['s']),[[x,y,math.radians(a)] for x,y,a in d['squares']]
    return float(d['side']),d['squares']

def basis(t):
    c=(1-t*t)/(1+t*t);s=2*t/(1+t*t)
    return (c,s),(-s,c)

def dot(a,b):return a[0]*b[0]+a[1]*b[1]

def vertices(x,y,t):
    u,v=basis(t)
    return [(x+(a*u[0]+b*v[0])/2,y+(a*u[1]+b*v[1])/2) for a,b in [(-1,-1),(1,-1),(1,1),(-1,1)]]

def exact_check(cert):
    """Check every pair by vertex projections, with exact rational arithmetic."""
    start=time.monotonic();L=F(cert['s_exact']);sq=[[F(z) for z in r] for r in cert['squares']]
    if len(sq)!=cert['n'] or L<=0:return {'valid':False,'reason':'invalid count or side'}
    vv=[vertices(*r) for r in sq];nn=[basis(r[2]) for r in sq]
    for i,V in enumerate(vv):
        if any(x<0 or y<0 or x>L or y>L for x,y in V):return {'valid':False,'reason':'wall','i':i}
    checked=0;by_bbox=0
    bb=[(min(x for x,y in V),max(x for x,y in V),min(y for x,y in V),max(y for x,y in V)) for V in vv]
    for i in range(len(sq)):
        for j in range(i):
            checked+=1;a,b=bb[i],bb[j]
            if a[1]<=b[0] or b[1]<=a[0] or a[3]<=b[2] or b[3]<=a[2]:by_bbox+=1;continue
            separated=False
            for n in (*nn[i],*nn[j]):
                A=[dot(v,n) for v in vv[i]];B=[dot(v,n) for v in vv[j]]
                if max(A)<=min(B) or max(B)<=min(A):separated=True;break
            if not separated:return {'valid':False,'reason':'overlap','pair':[j,i]}
    return {'valid':True,'n':len(sq),'pairs_checked':checked,'pairs_by_exact_axis_bbox':by_bbox,'side_decimal':float(L),'seconds':time.monotonic()-start}

def rationalize(side,pose,digits=14,guard_digits=13):
    """Round to rationals then compute sufficient exact center dilation.

    A positive guard is added. This certifies the dilated side, never the raw
    floating objective. Substantial overlaps can cause a substantially worse side.
    """
    q=lambda x:F(f'{x:.{digits}f}')
    sq=[[q(x),q(y),q(math.tan(a/2))] for x,y,a in pose];L=q(side)
    axes=[basis(t) for x,y,t in sq];d=F(1)
    for i,(x,y,t) in enumerate(sq):
        u,v=axes[i];h=(abs(u[0])+abs(u[1]))/2
        for z in [x,y,L-x,L-y]:
            if z<=0:raise ValueError('Center outside box')
            d=max(d,h/z)
        for j,(xx,yy,tt) in enumerate(sq[:i]):
            delta=(x-xx,y-yy);candidates=[]
            for n in (*axes[i],*axes[j]):
                sep=abs(dot(delta,n))
                if sep:
                    radius=sum(abs(dot(vv,n)) for vv in (*axes[i],*axes[j]))/2
                    candidates.append(radius/sep)
            if not candidates:raise ValueError('Coincident centers')
            d=max(d,min(candidates))
    den=10**guard_digits;d=F((d.numerator*den+d.denominator-1)//d.denominator+1,den)
    return {'n':len(sq),'s_exact':str(d*L),'note':'rational centers and t=tan(theta/2); c=(1-t²)/(1+t²), s=2t/(1+t²)',
            'dilation_exact':str(d),'raw_side':side,'squares':[[str(d*x),str(d*y),str(t)]for x,y,t in sq]}

def save_svg(path,side,pose,title=''):
    scale=720/side;items=[f'<svg xmlns="http://www.w3.org/2000/svg" width="780" height="810" viewBox="-30 -60 780 810">',f'<text x="0" y="-30" font-size="18">{title}</text>', '<rect width="720" height="720" fill="white" stroke="black"/>']
    for i,(x,y,a) in enumerate(pose):
        u=(math.cos(a),math.sin(a));v=(-u[1],u[0]);pts=[(scale*(x+(aa*u[0]+b*v[0])/2),720-scale*(y+(aa*u[1]+b*v[1])/2))for aa,b in [(-1,-1),(1,-1),(1,1),(-1,1)]]
        color='#dfe4e7' if abs(math.sin(2*a))<1e-8 else ('#72b6b0' if math.sin(4*a)>=0 else '#dbb774')
        items.append('<polygon points="'+' '.join(f'{xx:.5f},{yy:.5f}'for xx,yy in pts)+f'" fill="{color}" stroke="#333" stroke-width="0.6"/>')
        items.append(f'<text x="{x*scale:.4f}" y="{720-y*scale:.4f}" text-anchor="middle" font-size="8">{i}</text>')
    Path(path).write_text('\n'.join(items+['</svg>']))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('input');p.add_argument('--out');p.add_argument('--check-only',action='store_true');a=p.parse_args()
    if a.check_only:c=json.loads(Path(a.input).read_text())
    else:
        L,pose=load_pose(a.input);c=rationalize(L,pose)
        if a.out:Path(a.out).write_text(json.dumps(c,indent=2)+'\n')
    print(json.dumps(exact_check(c),indent=2))
