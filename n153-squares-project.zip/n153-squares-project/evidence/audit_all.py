"""Three exact geometric checks of every retained parent and composition.

The support checker below is adapted from the separately implemented N375
checker. The other two implementations use vertex projections and polygon
intersection respectively. No search or construction code is imported.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,time
from vertex_check import exact_check
from polygon_check import audit as polygon_audit

HERE=Path(__file__).resolve().parent


def support_audit(d):
    L=F(d['s_exact']);assert L>0
    rows=[]
    for x,y,t in d['squares']:
        x,y,t=F(x),F(y),F(t);den=1+t*t
        c=(1-t*t)/den;s=2*t/den;h=(abs(c)+abs(s))/2
        assert c*c+s*s==1
        assert h<=x<=L-h and h<=y<=L-h
        rows.append((x,y,(c,s),(-s,c)))
    assert len(rows)==d['n'] and d['n']>0
    count=0
    for i,a in enumerate(rows):
        for b in rows[:i]:
            dx,dy=a[0]-b[0],a[1]-b[1];separated=False
            for owner,other in ((a,b),(b,a)):
                for ux,uy in owner[2:]:
                    r=1+abs(ux*other[2][0]+uy*other[2][1])+abs(ux*other[3][0]+uy*other[3][1])
                    if 2*abs(dx*ux+dy*uy)>=r:separated=True;break
                if separated:break
            assert separated,('overlap',i,count)
            count+=1
    return {'valid':True,'n':len(rows),'pairs_checked':count,
            'method':'rational centre displacement and exact support radii; no bounding-box shortcut'}


def check(path):
    raw=path.read_bytes();d=json.loads(raw)
    vertex=exact_check(d);assert vertex['valid'],vertex
    vertex.pop('seconds',None)
    support=support_audit(d)
    polygon=polygon_audit(d)[0]
    assert vertex['pairs_checked']==support['pairs_checked']==polygon['pairs_checked']==d['n']*(d['n']-1)//2
    return {'path':str(path.relative_to(HERE)),
            'certificate_sha256':hashlib.sha256(raw).hexdigest(),
            'n':d['n'],'s_exact':d['s_exact'],'valid':True,
            'vertex_check':vertex,'support_check':support,'polygon_check':polygon}


if __name__=='__main__':
    assert __debug__,'Run without -O; assertions are required.'
    paths=[HERE/'packing.cert.json', HERE/'parents/n070.cert.json', HERE/'baselines/prior-153.cert.json']
    results=[]
    for path in paths:
        result=check(path);results.append(result)
        print('PASS',result['path'],result['n'],result['support_check']['pairs_checked'],flush=True)
    (HERE/'independent_audit.json').write_text(json.dumps({'valid':True,'certificates_checked':len(results),'results':results},indent=2)+'\n')
