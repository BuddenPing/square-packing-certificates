"""Independent symbolic derivation of the new capped contact return.

Requires SymPy only. This proves a necessary bound in the specified physical
contact family; the separate rational witness proves full packing feasibility.
"""
import sympy as S
import json
u,f=S.symbols('u f',real=True)
c=(1-u*u)/(1+u*u);s=2*u/(1+u*u)
h=(c+s)/2;D=(1+c+s)/2
U20,V20,U40,V40,U33,V33=S.symbols('U20 V20 U40 V40 U33 V33',real=True)
Ubase=S.Rational(3,2)*c-(S.Rational(7,2)+f)*s+D+1
A=U20-Ubase
b=-s*U20+c*V20-(2+h)
C=V40-V20-3
d=5+f-h-(c*U40+s*V40)
E=U40-U33-2
F=c*U33+s*V33-3-h
J=6+f-h-(-s*U33+c*V33)
weighted=S.factor(s*s*A+s*b+c*s*C+c*d+c*c*E+c**3*F+c*c*s*J)
fC=S.factor(S.solve(weighted,f)[0])
assert S.factor(weighted-(c+s)*(f-fC))==0
fA=S.factor((2-c)/(c+s))
P=u**7-9*u**6+3*u**5-u**4-u**3+u**2-3*u+1
assert S.factor((fA-fC)-2*u*P/((1+u*u)**3*(u*u-2*u-1)))==0
lo=S.Rational(3550051490362263,10**16);hi=S.Rational(3550051490362265,10**16)
assert S.Poly(P,u).count_roots(lo,hi)==1
assert P.subs(u,lo)*P.subs(u,hi)<0
root=S.nroots(P,maxsteps=300,n=60)
root=next(r for r in root if abs(S.im(r))<S.Rational(1,10**50) and lo<S.re(r)<hi)
print(json.dumps({'f_A':str(fA),'f_C':str(fC),'crossing_polynomial':str(P),
                  'positive_clearance_identity_verified':True,
                  'root_isolation':[str(lo),str(hi)],'u':str(root),
                  'theta_degrees':str(S.N(2*S.atan(root)*180/S.pi,45)),
                  'fraction_at_crossing':str(S.N(fA.subs(u,root),45)),
                  'scope':'necessary contact-family bounds; feasibility is separately proved by packing.cert.json'},indent=2))
