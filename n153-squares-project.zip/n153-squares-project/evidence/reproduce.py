"""Rebuild and verify the explicit rational N153 construction. Stdlib only.

This replays the released construction table, not the exploratory MILP/LP.
It independently recomputes the required exact guard and then runs three
geometric validators on the new packing and retained comparison witnesses.
"""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext,ROUND_CEILING
import json,hashlib
from audit_all import check

HERE=Path(__file__).resolve().parent

def basis(t):
    c=(1-t*t)/(1+t*t);s=2*t/(1+t*t)
    return (c,s),(-s,c)

def dot(a,b):return a[0]*b[0]+a[1]*b[1]

def reproduce():
    assert __debug__,'Run without -O; assertions are required.'
    recipe=json.loads((HERE/'rational_recipe.json').read_text())
    cert=json.loads((HERE/'packing.cert.json').read_text())
    sq=[[F(v) for v in r]for r in recipe['squares_before_guard']]
    L=F(recipe['side_before_guard']);axes=[basis(t)for x,y,t in sq]
    required=F(1)
    for i,(x,y,t) in enumerate(sq):
        u,v=axes[i];h=(abs(u[0])+abs(u[1]))/2
        for z in [x,y,L-x,L-y]:
            assert z>0;required=max(required,h/z)
        for j,(xx,yy,tt) in enumerate(sq[:i]):
            delta=(x-xx,y-yy);candidates=[]
            for normal in (*axes[i],*axes[j]):
                sep=abs(dot(delta,normal))
                if sep:
                    radius=sum(abs(dot(b,normal))for b in (*axes[i],*axes[j]))/2
                    candidates.append(radius/sep)
            assert candidates
            required=max(required,min(candidates))
    den=10**13
    guard=F((required.numerator*den+required.denominator-1)//required.denominator+1,den)
    assert guard==F(recipe['dilation_exact'])==F(cert['dilation_exact'])
    assert L*guard==F(cert['s_exact'])
    rebuilt=[[x*guard,y*guard,t]for x,y,t in sq]
    assert rebuilt==[[F(v)for v in r]for r in cert['squares']]
    assert len(rebuilt)==recipe['n']==cert['n']==153
    prior=json.loads((HERE/'baselines/regularized-153.cert.json').read_text())
    side=L*guard;old=F(prior['s_exact']);assert side<old
    with localcontext() as ctx:
        ctx.prec=90
        dec=lambda q:Decimal(q.numerator)/Decimal(q.denominator)
        numbers={'side_exact':str(side),'prior_side_exact':str(old),
                 'side_decimal_rounded_up':str(dec(side).quantize(Decimal('0.000000000001'),rounding=ROUND_CEILING)),
                 'side_gain_exact':str(old-side),'side_gain_decimal':str(dec(old-side)),
                 'area_gain_decimal':str(dec(old*old-side*side))}
    paths=['packing.cert.json','parents/n070.cert.json','parents/cycle-hit-153.cert.json',
           'baselines/prior-153.cert.json','baselines/regularized-153.cert.json']
    result={'valid':True,'construction_table_identity':True,'guard_recomputed_exactly':True,
            **numbers,'audits':[check(HERE/p)for p in paths]}
    (HERE/'reproduction_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'valid':True,**numbers,'certificates_checked':len(paths)},indent=2))
    return result

if __name__=='__main__':reproduce()
