#!/usr/bin/env python3
"""Verify the refined N207 release with Python's standard library."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
if not __debug__:
    raise RuntimeError("Run without -O")
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--skip-hashes", action="store_true", help="Development check before the release manifest is assembled")
parser.add_argument("--skip-native", action="store_true", help="Development check before the native bundle is assembled")
args = parser.parse_args()


def run(script, *arguments, ok=True):
    result = subprocess.run([sys.executable, "-B", str(root/script), *map(str, arguments)],
                            capture_output=True, text=True)
    if (result.returncode == 0) != ok:
        raise RuntimeError(result.stdout+result.stderr)
    return result.stdout


if not args.skip_hashes:
    for line in (root/"SHA256SUMS").read_text().splitlines():
        expected, name = line.split("  ", 1)
        if hashlib.sha256((root/name).read_bytes()).hexdigest() != expected:
            raise ValueError("Hash mismatch: "+name)

certificate = root/"evidence/packing.cert.json"
data = json.loads(certificate.read_text())
for text_name, json_name in [("n207.cert", "packing.cert.json"),
                             ("prior-n207.cert", "prior-n207.cert.json")]:
    rows = [line.split() for line in (root/"evidence"/text_name).read_text().splitlines() if line.strip()]
    original = json.loads((root/"evidence"/json_name).read_text())
    if rows[0] != [str(original["n"]), original["s_exact"]] or rows[1:] != original["squares"]:
        raise ValueError("Text/JSON identity mismatch: "+text_name)

geometry = json.loads(run("checkers/verify_n207.py", certificate))
assert geometry["valid"] and geometry["pairs_checked"] == 21321
assert geometry["wall_constraints_checked"] == 828
assert geometry["all_pairs_have_strict_separating_gap"]
for checker in ["verify_cert.py", "verify_cert2.py"]:
    run("checkers/"+checker, root/"evidence/n207.cert")
    run("checkers/"+checker, root/"evidence/prior-n207.cert")
run("construction/reproduce.py", "--certificate", certificate)
if not args.skip_native:
    run("native/convert_witness.py", certificate, root/"native/pingyou-n207-rational.yaml", "--check")

with tempfile.TemporaryDirectory() as directory:
    directory = Path(directory)
    for name in ["duplicate_square", "outside_wall", "missing_square"]:
        changed = json.loads(certificate.read_text())
        if name == "duplicate_square":
            changed["squares"][1] = changed["squares"][0][:]
        elif name == "outside_wall":
            changed["squares"][0][0] = "-1"
        else:
            changed["squares"].pop()
        a = directory/(name+".json")
        a.write_text(json.dumps(changed))
        b = directory/(name+".cert")
        b.write_text(str(changed["n"])+" "+changed["s_exact"]+"\n"+
                     "\n".join(" ".join(row) for row in changed["squares"])+"\n")
        run("checkers/verify_n207.py", a, ok=False)
        for checker in ["verify_cert.py", "verify_cert2.py"]:
            run("checkers/"+checker, b, ok=False)

print("PASS: 207 unit squares; 828 walls; 21321 pairs; three exact geometry checks; prior certificate; exact source-lineage and refined-table replay; duplicate, outside-wall and missing-square rejection controls.")
print("File hashes: "+("skipped by request" if args.skip_hashes else "PASS"))
print("Lossless native conversion: "+("skipped by request" if args.skip_native else "PASS"))
print("For the additional unchanged native verifier runs, see native/README.txt and native/native-replay.json.")
