"""Verify this submission bundle offline with Python's standard library."""
from pathlib import Path
from fractions import Fraction as F
import hashlib, json, subprocess, sys

ROOT=Path(__file__).resolve().parent
if not __debug__:
    raise SystemExit('Run without -O; verification requires assertions.')
manifest=json.loads((ROOT/'manifest.json').read_text())
for name,expected in manifest['sha256'].items():
    p=ROOT/name
    assert p.is_file(),f'Missing file: {name}'
    assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,f'Hash mismatch: {name}'
cert=json.loads((ROOT/'evidence/packing.cert.json').read_text())
binding=json.loads((ROOT/'evidence/document-binding.json').read_text())
geom=json.dumps({k:cert[k] for k in ['n','s_exact','squares']},sort_keys=True,separators=(',',':')).encode()
assert hashlib.sha256(geom).hexdigest()==binding['canonical_geometry_sha256']
proc=subprocess.run([sys.executable,'-B',str(ROOT/'evidence/reproduce.py')],capture_output=True,text=True,check=True)
audit=json.loads(proc.stdout)
assert audit['valid'] and audit['exact_coordinate_identity']
assert audit['audit']['n']==207 and audit['audit']['support_check']['pairs_checked']==21321

for path in (ROOT/'native').glob('*.cert'):
    rows=[s.split() for s in path.read_text().splitlines() if s.strip() and not s.lstrip().startswith('#')]
    assert len(rows)==208 and rows[0][0]=='207' and F(rows[0][1])==F(cert['s_exact'])
    assert [list(map(F,r)) for r in rows[1:]]==[list(map(F,r)) for r in cert['squares']]
    for tool in ['verify_cert.py','verify_cert2.py']:
        p=ROOT/'upstream-atlas'/tool
        if p.exists():
            subprocess.run([sys.executable,'-B',str(p),str(path)],check=True,capture_output=True,text=True)

# Witness/v2 is emitted as JSON, a strict subset of YAML, for portable replay.
for path in (ROOT/'native').glob('pingyou-*.yaml'):
    witness=json.loads(path.read_text())['witness']
    assert witness['n']==207 and F(witness['side'])==F(cert['s_exact'])
    assert witness['square_size']=='1' and witness['representation']=='corners'
    assert len(witness['squares'])==207
    for source,target in zip(cert['squares'],witness['squares']):
        x,y,t=map(F,source);c,s=(1-t*t)/(1+t*t),2*t/(1+t*t)
        expected={(x+(a*c-b*s)/2,y+(a*s+b*c)/2) for a,b in [(-1,-1),(1,-1),(1,1),(-1,1)]}
        assert {tuple(map(F,p)) for p in target['corners']}==expected

converter=ROOT/'native/convert_witness.py'
if converter.exists():
    subprocess.run([sys.executable,'-B',str(converter),str(ROOT/'evidence/packing.cert.json'),str(ROOT/'native/pingyou-n207-rational.yaml'),'--check'],check=True,capture_output=True,text=True)

# The King's/legacy decimal format is checked by its provided adapter, if present.
extra=ROOT/'native/verify_export.py'
if extra.exists():
    subprocess.run([sys.executable,'-B',str(extra)],check=True,capture_output=True,text=True)
print(json.dumps({'valid':True,'manifest_files':len(manifest['sha256']),'n':207,'pairs':21321,
    'coordinate_reconstruction':True,'three_exact_geometry_checks':True,'native_export_checks':True},indent=2))
