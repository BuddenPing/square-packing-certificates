"""Reconstruct the released N207 rational witness; Python standard library only.

The input is an explicit rational construction table, not an optimization seed.
No optimizer, network access, or external repository is needed. The optional
--certificate argument checks exact geometry against a separately supplied file.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import argparse
import hashlib
import json

HERE = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(d):
    return {"n": d["n"], "s_exact": str(F(d["s_exact"])),
            "squares": [[str(F(v)) for v in row] for row in d["squares"]]}


def digest(d):
    data = json.dumps(canonical(d), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(data.encode()).hexdigest()


def basis(t):
    c, s = (1-t*t)/(1+t*t), 2*t/(1+t*t)
    require(c*c+s*s == 1, "unit-square identity")
    return (c, s), (-s, c)


def dot(a, b):
    return a[0]*b[0]+a[1]*b[1]


def check_geometry(d):
    """All walls and all unordered pairs; exact separating-axis arithmetic."""
    rows = [[F(v) for v in row] for row in d["squares"]]
    require(len(rows) == d["n"], "square count")
    side = F(d["s_exact"])
    axes = [basis(t) for x, y, t in rows]
    radii = [(abs(u[0])+abs(u[1]))/2 for u, v in axes]
    pairs, bounding_box_pairs = 0, 0
    for i, (x, y, t) in enumerate(rows):
        h = radii[i]
        require(min(x, y, side-x, side-y) >= h, "wall violation at owner %d" % i)
        for j in range(i):
            pairs += 1
            delta = (x-rows[j][0], y-rows[j][1])
            if max(abs(delta[0]), abs(delta[1])) >= h+radii[j]:
                bounding_box_pairs += 1
                continue
            separated = False
            for normal in (*axes[i], *axes[j]):
                radius = sum(abs(dot(b, normal)) for b in (*axes[i], *axes[j]))/2
                if abs(dot(delta, normal)) >= radius:
                    separated = True
                    break
            require(separated, "overlap at owners %d,%d" % (j, i))
    return {"valid": True, "unit_squares": len(rows),
            "wall_inequalities": 4*len(rows), "pairs": pairs,
            "pairs_separated_by_axis_bounding_boxes": bounding_box_pairs}


def required_guard(side, rows):
    """Compute the exact smallest common center/host dilation for this table.

    Only dilation factors >=1 are considered; each square retains unit side.
    A pair needs the minimum required factor over its four edge normals.
    """
    required = F(1)
    axes = [basis(t) for x, y, t in rows]
    radii = [(abs(u[0])+abs(u[1]))/2 for u, v in axes]
    for i, (x, y, t) in enumerate(rows):
        h = radii[i]
        for distance in [x, y, side-x, side-y]:
            require(distance > 0, "nonpositive wall distance before guard")
            required = max(required, h/distance)
        for j in range(i):
            delta = (x-rows[j][0], y-rows[j][1])
            if max(abs(delta[0]), abs(delta[1])) >= h+radii[j]:
                continue
            options = []
            for normal in (*axes[i], *axes[j]):
                distance = abs(dot(delta, normal))
                if distance:
                    radius = sum(abs(dot(b, normal)) for b in (*axes[i], *axes[j]))/2
                    options.append(radius/distance)
            require(options, "coincident centers")
            required = max(required, min(options))
    return required


def vertices(row):
    x, y, t = row
    (c, s), _ = basis(t)
    return [(x+(a*c-b*s)/2, y+(a*s+b*c)/2)
            for a, b in [(-1, -1), (1, -1), (1, 1), (-1, 1)]]


def source_patch(source, spec):
    side = F(source["s_exact"])
    out = []
    for owner in spec["source_owners"]:
        x, y, t = map(F, source["squares"][owner])
        (c, s), _ = basis(t)
        if spec["corner"] & 1:
            x, c = side-x, -c
        if spec["corner"] & 2:
            y, s = side-y, -s
        if spec["swap"]:
            x, y, c, s = y, x, s, c
        t = F(0) if c == -1 else s/(1+c)
        out.append((x, y, t))
    return out


def reconstruct():
    recipe = json.loads((HERE/"rational_recipe.json").read_text())
    raw = (HERE/"source70.cert.json").read_bytes()
    require(hashlib.sha256(raw).hexdigest() == recipe["source70_sha256"], "source hash")
    source = json.loads(raw)
    require(source["n"] == len(source["squares"]) == 70, "source count")
    A, B = [source_patch(source, spec) for spec in recipe["parent_patches"]]
    require(len(A) == 60 and len(B) == 69, "whole-source-owner counts")
    dimensions = recipe["parent_dimensions"]
    m, i, j, u, v = [dimensions[k] for k in ["m", "i", "j", "u", "v"]]
    require((m, i, j, u, v) == (14, 7, 8, 8, 8), "assembly dimensions")
    extents = [F(0)]
    for patch, width, height in [(A, i, j), (B, u, v)]:
        for row in patch:
            points = vertices(row)
            extents.extend([max(x for x, y in points)-width,
                            max(y for x, y in points)-height])
    fraction = max(extents)
    require(0 < fraction < 1 and fraction == F(recipe["parent_fraction_exact"]), "source envelope")
    parent_rows = A + [(x+m-u, y+m-v, t) for x, y, t in B]
    parent_rows += [(i+fraction+x+F(1, 2), y+F(1, 2), F(0))
                    for x in range(m-i) for y in range(m-v)]
    parent_rows += [(x+F(1, 2), j+fraction+y+F(1, 2), F(0))
                    for x in range(m-u) for y in range(m-j)]
    require(len(parent_rows) == recipe["n"] == 207, "complete owner count")
    parent_guard = F(recipe["parent_center_guard"])
    parent = {"n": 207, "s_exact": str((m+fraction)*parent_guard),
              "squares": [[str(x*parent_guard), str(y*parent_guard), str(t)]
                          for x, y, t in parent_rows]}
    require(digest(parent) == recipe["parent_geometry_sha256"], "original assembly identity")

    # The refined witness retains this owner order. Exact rounding of the
    # inherited half-angle parameters reproduces all its rational frames.
    angle_denominator = 10**recipe["inherited_half_angle_decimal_places"]
    frames = [F(round(t*angle_denominator), angle_denominator) for x, y, t in parent_rows]
    require(Counter(frames) == {F(0): 119, F(-1): 50,
                               F(-4642566678281, 12500000000000): 19,
                               F(-22917902170607, 50000000000000): 19}, "inherited rounded frames")
    denominator = int(recipe["coordinate_denominator_before_guard"])
    numerators = recipe["centers_before_guard_numerators"]
    require(denominator > 0 and len(numerators) == 207, "rational center table")
    rows = [[F(x, denominator), F(y, denominator), t]
            for (x, y), t in zip(numerators, frames)]
    side = F(recipe["refined_side_before_guard"])
    needed = required_guard(side, rows)
    guard_denominator = 10**recipe["guard_grid_decimal_places"]
    guard = F((needed.numerator*guard_denominator+needed.denominator-1)//needed.denominator+1,
              guard_denominator)
    require(guard == F(recipe["refined_center_guard"]), "exact guard recomputation")
    result = {"n": 207, "s_exact": str(side*guard),
              "squares": [[str(x*guard), str(y*guard), str(t)] for x, y, t in rows]}
    require(digest(result) == recipe["refined_geometry_sha256"], "refined geometry identity")
    require(F(result["s_exact"]) < F(parent["s_exact"]), "strict side improvement")
    report = {"valid": True, "source_geometry": check_geometry(source),
              "original_assembly_exactly_reconstructed": True,
              "original_assembly_geometry": check_geometry(parent),
              "source_patch_counts": [60, 69], "added_grid_counts": [42, 36],
              "refined_owner_count": 207, "refined_orientations_mod_90_counts": [169, 19, 19],
              "all_refined_frames_equal_exact_rounding_of_inherited_frames": True,
              "half_angle_decimal_places": recipe["inherited_half_angle_decimal_places"],
              "guard_recomputed_exactly": str(guard),
              "previous_guard": str(parent_guard),
              "final_geometry": check_geometry(result),
              "side_exact": result["s_exact"],
              "improvement_exact": str(F(parent["s_exact"])-F(result["s_exact"])),
              "geometry_sha256": digest(result),
              "scope": "Complete owner-lineage reconstruction and explicit rational-table replay; no floating solve, angle search or optimality claim."}
    return result, report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--certificate", type=Path, help="Compare a supplied certificate's exact geometry")
    parser.add_argument("--output", type=Path, help="Write the reconstructed portable JSON certificate")
    parser.add_argument("--receipt", type=Path, help="Write the replay/check receipt")
    args = parser.parse_args()
    certificate, report = reconstruct()
    if args.certificate:
        supplied = json.loads(args.certificate.read_text())
        require(canonical(supplied) == canonical(certificate), "supplied certificate mismatch")
        report["supplied_certificate_matches"] = True
    if args.output:
        args.output.write_text(json.dumps(certificate, indent=2)+"\n")
    if args.receipt:
        args.receipt.write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()


