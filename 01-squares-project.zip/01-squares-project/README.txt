N207: refined rational certificate
PingYou Ltd — 12 October 2026

This package gives 207 closed unit squares with disjoint interiors in a square
of exact side

  3720240092889639048018577779 / 250000000000000000000000000
  = 14.880960371558556192074311116.

An upward-rounded bound at 12 decimal places is 14.880960371559.

This refines the earlier N207 submission in Squares Project issue #503 and
record T-147. The earlier exact side was
14.8809603730436756319360591381170501178639. The decrease is
0.0000000014851194398617480221170501178639.

The square count and whole-owner composition are retained: two transformed
patches of Ryan Xu's N70 packing supply 60 and 69 squares, and two upright
grids supply 42 and 36. The refinement has new rational centers, inherited
half-angle parameters rounded to 14 decimal places, and a smaller common
center/host guard: 1 + 2e-13 instead of 1 + 1e-10. It is a coordinate and
rationalization refinement, not a new count or a new angle-search result.
The old rigid-patch recipe alone does not regenerate these refined centers.

VERIFY

Extract the archive, enter its folder, and run:

  python3 VERIFY.py

Python 3.10 or later is sufficient; no third-party Python modules or network
access are required. Do not use Python's -O option. This checks release file
hashes, exact text/JSON correspondence, all 207 unit-square shapes, all 828
wall inequalities, all 21,321 unordered square pairs, the previous certificate,
the construction replay, lossless native conversion, and rejection controls.

The separate native upstream verifier results and requirements are documented
in native/README.txt. Those optional upstream programs are not installed or
invoked by VERIFY.py; its native step checks the exact coordinate conversion.

To replay the construction by itself:

  python3 construction/reproduce.py --certificate evidence/packing.cert.json

To write a regenerated certificate:

  python3 construction/reproduce.py --output replayed.cert.json

CONTENTS

evidence/packing.cert.json       Authoritative refined exact rational geometry.
evidence/n207.cert               The same geometry in Evan Daniel's text format.
evidence/prior-n207.cert.json    The earlier submitted geometry for comparison.
evidence/comparison.json         Exact numerical comparison and source pointers.
evidence/document-binding.json  Original and portable file/geometry bindings.
evidence/exact-audit.json        Exhaustive exact polygon-projection audit.
evidence/upstream-replay.json    Unchanged Evan Daniel verifier run receipts.
construction/                   Complete source-owner lineage and table replay.
checkers/                       Exact verification programs and upstream license.
native/                         Lossless native witness and upstream test receipts.

Exact coordinates use rows [x, y, t], where t = tan(theta/2). The unit-square
edge vectors are ((1-t*t)/(1+t*t), 2*t/(1+t*t)) and its quarter-turn. The final
geometry has three orientations modulo 90 degrees, populated by 169, 19 and
19 squares. The exact minimum wall clearance is 1e-13; the minimum best
separating-axis gap over square pairs is about 1.896287267895e-13.

SCOPE AND CREDIT

Construction and refinement: PingYou Ltd. N70 source construction: Ryan Xu.
Exact N70 retention and the two upstream exact checkers: Evan Daniel. The
source announcement is https://github.com/jlevy/squares/issues/432 . Pinned
source URLs and hashes are in construction/PROVENANCE.json and checkers/.
The upstream MIT license is retained in checkers/ATLAS-LICENSE.txt.

The supplied checks establish feasibility and strict improvement over the
identified earlier certificate. They do not establish global optimality.
The implementations are separate geometry checks, not independent human
audits. The replay includes an explicit complete rational center table; it
does not repeat exploratory owner selection or the original numerical solve.
