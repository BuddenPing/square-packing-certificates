PINGYOU LTD — N207 EXACT SQUARE-PACKING SUBMISSION EVIDENCE
Prepared 11 October 2026. No submission or external acceptance is claimed.

RESULT
207 unit squares fit in a square of side at most 14.880960373044.
This decimal is rounded UP. The exact side is:
148809603730436756319360591381170501178639/10000000000000000000000000000000000000000
= 14.8809603730436756319360591381170501178639.

The strongest prior public witness located on 11 October 2026 is SQUISH's
9 October N207 certificate at 14.88550630884167768241355419580841135922855...,
reported in https://github.com/jlevy/squares/issues/481 . The exact side
reduction is approximately 0.00454593579800205 (0.03054%).
This is a new best-known upper-bound claim; global optimality is not claimed.

VERIFY OFFLINE — Python 3.10 or newer; standard library only
Run from any directory:
    python3 /path/to/evidence/reproduce.py
Do not use -O: the checkers intentionally use assertions.
The script reconstructs all 207 exact poses from the retained N70 source,
compares every pose and the side with packing.cert.json, and checks the new
packing, source and prior witness with three exact geometry implementations.
It writes reproduction_audit.json. All 21,321 new-packing pairs and all walls
are checked. Two implementations use separating axes (different formulations);
the third clips rational polygons. All use the same exact input data.

CERTIFICATE FORMAT
packing.cert.json contains n, s_exact and squares. Each square is a row
[x, y, t] of rational strings: its centre and t = tan(theta/2).
Use c=(1-t*t)/(1+t*t), s=2*t/(1+t*t). Its four vertices are
(x+(a*c-b*s)/2, y+(a*s+b*c)/2), (a,b)=(-1,-1),(1,-1),(1,1),(-1,1).
The container is [0,L] x [0,L]. Touching is allowed; interior overlap is not.
The side of each small square is EXACTLY 1. The final guard multiplies centres
and container side by 10000000001/10000000000, without changing small-square
side lengths or orientations. The reported bound already includes this guard.

CONSTRUCTION AND CREDIT
New N207 assembly: PingYou Ltd.
N70 source construction: Ryan Xu, https://github.com/jlevy/squares/issues/432 .
The exact N70 source was retained from Evan Daniel's repository; its pinned
source URL and source-file hash are inside parents/n070.cert.json.
Prior N207 benchmark: Nate Chaoweeraprasit (SQUISH), issue #481.
No claim is made to invent the N70 packing or patch composition in general.

Two differently placed N70 patches retain 60 and 69 whole unit squares.
The second is reflected in both axes, transposed, and translated by (6,6).
Add 7x6 and 6x6 grids: 60+69+42+36=207. The nominal patch bounding boxes
overlap, but their retained square interiors do not. The exact owner lists,
transformations, dimensions and guard are in the certificate provenance.

FILES
packing.cert.json             Authoritative portable exact witness.
parents/n070.cert.json         Byte-preserved exact source and its provenance.
baselines/prior-n207.cert.json Byte-preserved SQUISH comparison witness.
reproduce.py                  Exact reconstruction and three-check replay.
audit_all.py, vertex_check.py, polygon_check.py — exact geometry checkers.
reproduction_audit.json        Retained output from a fresh replay.
public-comparison.json        Prior exact bound, source URLs, dated review.
document-binding.json         Original/portable hashes and geometry identity.
n207-verified-comparison.pdf   Original two-page comparison, unchanged.
n207.svg                      Illustration computed from the exact witness.
centres-and-halfangles.csv     Exact rational centre/halfangle export.
vertices-exact.csv             Exact rational polygon vertices.
vertices-decimal.csv           50-digit decimal preview; exact JSON governs.

PORTABILITY
Only the original certificate's two machine-local source path metadata strings
were replaced by parents/n070.cert.json. Coordinates, orientations, side,
source hashes and all other values are unchanged. document-binding.json records
the original certificate hash and the portable hash. The PDF is byte-identical
to the reviewed original. No private filesystem paths are needed to replay.
Source credit is retained; this package adds no licence grant for third-party
material and does not assert that a catalogue has accepted this result.
