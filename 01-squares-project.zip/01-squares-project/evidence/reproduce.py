"""Independently reconstruct N207 from the retained exact N70 source.

Python standard library only. Run from any working directory, without -O.
The certificate is left byte-for-byte unchanged. Its historical absolute
source paths are resolved to the included parents directory by basename.
"""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal, localcontext, ROUND_CEILING
import hashlib
import json

HERE = Path(__file__).resolve().parent


def vertices(row):
    x, y, t = row
    c, s = (1-t*t)/(1+t*t), 2*t/(1+t*t)
    return [(x+(a*c-b*s)/2, y+(a*s+b*c)/2)
            for a, b in [(-1,-1), (1,-1), (1,1), (-1,1)]]


def source_patch(spec, owners, expected_hash):
    path = HERE / 'parents' / Path(spec['path']).name
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected_hash
    source = json.loads(raw)
    side = F(source['s_exact'])
    out = []
    for owner in owners:
        x, y, t = map(F, source['squares'][owner])
        c, s = (1-t*t)/(1+t*t), 2*t/(1+t*t)
        if spec['corner'] & 1:
            x, c = side-x, -c
        if spec['corner'] & 2:
            y, s = side-y, -s
        if spec['swap']:
            x, y, c, s = y, x, s, c
        # c=-1 is the same unoriented square as t=0.
        t = F(0) if c == -1 else s/(1+c)
        out.append((x, y, t))
    return out


def reproduce():
    assert __debug__, 'Run without -O: verification uses assertions.'
    cert = json.loads((HERE/'packing.cert.json').read_text())
    p = cert['provenance']
    A = source_patch(p['A_source'], p['A_retained_original_owners'], p['A_sha256'])
    B = source_patch(p['B_source'], p['B_retained_original_owners'], p['B_sha256'])
    m, i, j, u, v = (p['dimensions'][k] for k in ('m','i','j','u','v'))
    required = [F(0)]
    for patch, width, height in ((A,i,j), (B,u,v)):
        for sq in patch:
            points = vertices(sq)
            required.extend([max(x for x,y in points)-width,
                             max(y for x,y in points)-height])
    f = max(required)
    assert 0 < f < 1 and f == F(p['fraction_exact'])
    rows = A + [(x+m-u, y+m-v, t) for x,y,t in B]
    rows += [(i+f+x+F(1,2), y+F(1,2), F(0))
             for x in range(m-i) for y in range(m-v)]
    rows += [(x+F(1,2), j+f+y+F(1,2), F(0))
             for x in range(m-u) for y in range(m-j)]
    dilation = F(p['outward_center_dilation_exact'])
    rows = [(dilation*x, dilation*y, t) for x,y,t in rows]
    assert len(rows) == cert['n'] == 207
    assert rows == [tuple(map(F,row)) for row in cert['squares']]
    side = (m+f)*dilation
    assert side == F(cert['s_exact'])
    prior = json.loads((HERE/'baselines/prior-n207.cert.json').read_text())
    prior_side = F(prior['s_exact'])
    assert side < prior_side
    with localcontext() as ctx:
        ctx.prec = 80
        value = Decimal(side.numerator)/Decimal(side.denominator)
        rounded_up = str(value.quantize(Decimal('0.000000000001'), rounding=ROUND_CEILING))
        gain = prior_side-side
        gain_decimal = str(Decimal(gain.numerator)/Decimal(gain.denominator))
    from audit_all import check
    result = {
        'valid': True,
        'exact_coordinate_identity': True,
        'source_sha256': p['A_sha256'],
        'retained_counts': {'A': len(A), 'B': len(B),
                            'grid_1': (m-i)*(m-v), 'grid_2': (m-u)*(m-j)},
        'side_exact': str(side),
        'side_decimal_rounded_up': rounded_up,
        'prior_side_exact': str(prior_side),
        'gain_exact': str(gain),
        'gain_decimal': gain_decimal,
        'audit': check(HERE/'packing.cert.json'),
        'source_audit': check(HERE/'parents/n070.cert.json'),
        'prior_audit': check(HERE/'baselines/prior-n207.cert.json'),
    }
    (HERE/'reproduction_audit.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))
    return result


if __name__ == '__main__':
    reproduce()
