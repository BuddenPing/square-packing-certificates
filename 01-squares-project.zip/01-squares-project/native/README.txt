N207 refined exact rational Witness/v2

Construction credit: PingYou Ltd.
Underlying N70 contact skeleton: Ryan Xu.
Retained N70 source certificate: Evan Daniel.

This witness contains exactly 207 unit squares with rational corners at side
3720240092889639048018577779/250000000000000000000000000
= 14.880960371558556192074311116. A safe upward display is 14.880960371558557.
It is a feasible upper bound; no local or global optimality is claimed.

The portable source certificate SHA-256 is 94dc19ce0ab4e8c35de7a4a542ff2b46d0dafe717bb84ebf6d3fcd351a212a5c.
The native witness SHA-256 is 7a683bfc118080e9eb8922549130a64f84caa402d565a5fdd5e0a2cd22819497.
source-binding.json also binds the reviewed snapshot and canonical geometry.
The witness's source path is ../evidence/packing.cert.json.

Exact conversion
The standard-library converter maps every [x,y,t] using
(c,s)=((1-t*t)/(1+t*t),2*t/(1+t*t)) and four signed half-edge sums.
Its --check mode recovers every centre and half-angle, checks unit edges and
containment, and preserves square order. conversion-check.json binds the
portable source bytes to this witness. It is not a pairwise feasibility check.

From a release root with native/ and evidence/:
python3 -B native/convert_witness.py evidence/packing.cert.json native/pingyou-n207-rational.yaml --check

Pinned upstream verification
The retained upstream files are unchanged from jlevy/squares commit
074ac28d4ceb9a1897303f936d794771cfc6a7bd.
upstream-source-manifest.json binds each file, including the schema and license.
The wrapper verifies those hashes before importing. Both unchanged verifier
implementations passed 207 squares and 21,321 pairs:
sqpack.witness.exact_verify and devtools.check_rational_witness_independent.
They report identical exact margins and no failures.
Minimum wall clearance: 1/10000000000000.
First route: 3.321s; second: 1.537s.
See native-replay.json for the full exact results and dependency versions.

Reproduce with Python 3.14 and the pinned dependencies:
uv run --no-project --python 3.14 --with mpmath==1.4.1 --with PyYAML==6.0.3 --with jsonschema==4.26.0 --with strif==3.1.0 python -B native/replay_upstream.py --witness native/pingyou-n207-rational.yaml

Alternatively install these dependencies into a Python 3.14 environment and
run the wrapper directly. It defaults to native/upstream, a focused source
subset. A full checkout at the pinned revision may be supplied with --checkout.
The ordinary upstream command from its packing/ directory is:
uv run --frozen packing-witness verify /path/to/native/pingyou-n207-rational.yaml --json

This replay used unchanged verifier entry points. It was not a full repository
test run or maintainer endorsement of this refinement. All checkers consume
the same rational geometry. They establish finite feasibility, not optimality.

Upstream software and schema credit: Joshua Levy, the squares project,
https://github.com/jlevy/squares. The unchanged upstream license is retained
as UPSTREAM-LICENSE.txt and upstream/LICENSE. The retained upstream files
remain subject to that license.
