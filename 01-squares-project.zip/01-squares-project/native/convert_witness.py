#!/usr/bin/env python3
"""Lossless N207 half-angle -> Witness/v2 conversion; Python standard library.

Run from a submission package root:
    python3 native/convert_witness.py evidence/packing.cert.json native/pingyou-n207-rational.yaml
    python3 native/convert_witness.py evidence/packing.cert.json native/pingyou-n207-rational.yaml --check

JSON syntax is deliberately used: it is valid YAML 1.2 and permits replay with
the standard library. --check reads the existing file and recovers the source
centre and half-angle from its corners, without rewriting either artifact.
It checks conversion identity, unit squares, and containment. Pairwise
feasibility is established separately by evidence/reproduce.py and the
Squares Project's exact witness verifier.
"""
import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import time


def require(condition, message):
    if not condition:
        raise ValueError(message)


def unique_object(pairs):
    out = {}
    for key, value in pairs:
        require(key not in out, f"Duplicate JSON key: {key}")
        out[key] = value
    return out


def load(path):
    return json.loads(path.read_text(), object_pairs_hook=unique_object)


def convert(cert):
    require(cert['n'] == len(cert['squares']) == 207, 'Expected all 207 squares')
    squares = []
    for index, row in enumerate(cert['squares'], 1):
        x, y, t = map(F, row)
        c, s = (1-t*t)/(1+t*t), 2*t/(1+t*t)
        points = [[str(x+(a*c-b*s)/2), str(y+(a*s+b*c)/2)]
                  for a, b in ((-1,-1), (1,-1), (1,1), (-1,1))]
        squares.append({'id': index, 'corners': points})
    return {
        'softschema': {'contract': 'packing.squares:Witness/v2',
                       'schema': 'witness.schema.yaml',
                       'envelope': 'witness', 'status': 'enforced'},
        'witness': {
            'id': 'W-pingyou-n207-rational', 'n': 207,
            'side': str(F(cert['s_exact'])), 'square_size': '1',
            'representation': 'corners', 'scalar': {'kind': 'rational'},
            'coordinates': {'origin': 'lower-left', 'axes': 'x-right-y-up',
                            'angle_unit': 'not-applicable'},
            'squares': squares,
            'claim': {'coordinate_provenance': 'verified',
                      'method': 'exact-algebraic',
                      'limitations': 'Exact feasible upper bound only; no claim of local or global optimality.'},
            'source': {'path': '../evidence/packing.cert.json'},
            'certificate': {
                'kind': 'exact-rational-sat',
                'replay': 'From a pinned Squares Project packing/ checkout: uv run --frozen packing-witness verify /path/to/native/pingyou-n207-rational.yaml --json',
                'conversion': 'python3 native/convert_witness.py evidence/packing.cert.json native/pingyou-n207-rational.yaml --check'
            }
        }
    }


def check_identity(cert, document):
    require(document['softschema']['contract'] == 'packing.squares:Witness/v2', 'Wrong contract')
    w = document['witness']
    require(w['representation'] == 'corners' and w['scalar'] == {'kind': 'rational'}, 'Wrong representation')
    require(w['coordinates'] == {'origin': 'lower-left', 'axes': 'x-right-y-up', 'angle_unit': 'not-applicable'}, 'Wrong frame')
    require(w['square_size'] == '1', 'Wrong square size')
    require(w['n'] == cert['n'] == len(w['squares']) == len(cert['squares']) == 207, 'Wrong count')
    side = F(w['side'])
    require(side == F(cert['s_exact']) and side > 0, 'Side changed')
    for index, (source, sq) in enumerate(zip(cert['squares'], w['squares']), 1):
        require(sq['id'] == index, f'Square {index}: ID/order changed')
        points = [tuple(map(F, p)) for p in sq['corners']]
        require(len(points) == 4 and all(len(p) == 2 for p in points), 'Wrong corners')
        edges = [(points[(j+1)%4][0]-points[j][0], points[(j+1)%4][1]-points[j][1]) for j in range(4)]
        c, s = edges[0]
        require(c*c+s*s == 1, f'Square {index}: nonunit edge')
        require(edges == [(c,s),(-s,c),(-c,-s),(s,-c)], f'Square {index}: incorrect vertex order or shape')
        require(1+c != 0, f'Square {index}: cannot recover finite source half-angle')
        recovered = (sum(p[0] for p in points)/4, sum(p[1] for p in points)/4, s/(1+c))
        require(recovered == tuple(map(F, source)), f'Square {index}: source pose changed')
        require(all(0 <= v <= side for p in points for v in p), f'Square {index}: outside box')
    return {'valid': True, 'n': w['n'], 'side_exact': str(side),
            'exact_roundtrip_pose_identity': True, 'unit_square_shapes': True,
            'containment': True, 'pairs_checked': 0,
            'scope': 'Conversion identity, unit-square geometry, and containment; pairwise feasibility checked separately.'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('source', type=Path)
    p.add_argument('output', type=Path)
    p.add_argument('--check', action='store_true')
    args = p.parse_args()
    started = time.perf_counter()
    require(args.source.resolve() != args.output.resolve(), 'Source and output must differ')
    cert = load(args.source)
    if args.check:
        document = load(args.output)
        report = check_identity(cert, document)
    else:
        require(not args.output.exists(), 'Output exists; use --check or choose a new file')
        document = convert(cert)
        report = check_identity(cert, document)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(document, indent=2)+'\n')
    report['source_sha256'] = hashlib.sha256(args.source.read_bytes()).hexdigest()
    report['witness_sha256'] = hashlib.sha256(args.output.read_bytes()).hexdigest()
    report['elapsed_seconds'] = time.perf_counter()-started
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
