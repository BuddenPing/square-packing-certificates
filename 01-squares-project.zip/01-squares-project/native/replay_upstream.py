#!/usr/bin/env python3
"""Replay an unchanged Squares Project checkout against the native witness.

From its packing/ directory, using its installed dependencies:
    uv run --frozen python /path/to/native/replay_upstream.py --checkout ..
"""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import sys
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--checkout', type=Path, required=True)
p.add_argument('--witness', type=Path, default=Path(__file__).with_name('pingyou-n207-rational.yaml'))
args = p.parse_args()
sys.path.insert(0, str(args.checkout.resolve()/'packing'))
sys.path.insert(0, str(args.checkout.resolve()/'packing/src'))
from sqpack.witness import load_witness, exact_verify
from devtools.check_rational_witness_independent import check

start = time.perf_counter()
w = load_witness(args.witness)
result, report = exact_verify(w)
result['elapsed_seconds'] = time.perf_counter()-start
start = time.perf_counter()
independent = check(args.witness)
out = {
    'python': platform.python_version(),
    'witness_sha256': hashlib.sha256(args.witness.read_bytes()).hexdigest(),
    'entrypoint': 'sqpack.witness.load_witness followed by sqpack.witness.exact_verify (same functions as packing-witness verify)',
    'native_replay': result,
    'upstream_independent_checker': independent,
    'independent_elapsed_seconds': time.perf_counter()-start,
}
print(json.dumps(out, indent=2))
sys.exit(0 if report.valid and independent['verification_passed'] else 1)
